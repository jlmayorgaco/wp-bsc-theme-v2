<?php
namespace BSC\Admin2\Core;

defined('ABSPATH') || exit;

abstract class BaseView {
    /**
     * Renders the view using the provided data array.
     */
    abstract public function render(array $data = []): void;
}
