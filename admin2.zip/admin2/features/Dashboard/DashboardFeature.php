<?php
namespace BSC\Admin2\Features\Dashboard;

defined('ABSPATH') || exit;

class DashboardFeature {
    public function render(): void {
        if ( ! current_user_can('read') ) {
            wp_die( esc_html__( 'No tienes permisos para ver esta página.', 'bsc-2-0' ) );
        }

        $service = new DashboardService(new DashboardRepo());

        if ( isset($_GET['bsc_clear_cache']) && strtolower($_GET['bsc_clear_cache']) === 'dashboard' ) {
            $service->clearCache();
        }

        $kpis = $service->getKpiData();

        $view = new DashboardView();
        $view->render($kpis);
    }
}
