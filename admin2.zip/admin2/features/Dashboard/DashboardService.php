<?php
namespace BSC\Admin2\Features\Dashboard;

defined('ABSPATH') || exit;

class DashboardService {
    private DashboardRepo $repo;
    private string $cache_key = 'bsc_dashboard_kpis';
    private int $cache_time = 30 * MINUTE_IN_SECONDS;

    public function __construct(DashboardRepo $repo) {
        $this->repo = $repo;
    }

    public function getKpiData(): array {
        $kpis = get_transient($this->cache_key);

        if (false === $kpis) {
            $todayData = $this->repo->getTodaySalesAndOrdersCount();
            $statusCounts = $this->repo->getStatusCounts();
            $low_threshold = (int) get_option('bsc_low_stock_threshold', 3);

            $kpis = [
                'ventas_hoy'     => $todayData['ventas_hoy'],
                'pedidos_hoy'    => $todayData['pedidos_hoy'],
                'pendientes'     => $statusCounts['pendientes'],
                'preparando'     => $statusCounts['preparando'],
                'enviados'       => $statusCounts['enviados'],
                'recent_orders'  => $this->repo->getRecentOrders(5),
                'low_stock_ids'  => $this->repo->getLowStockProducts($low_threshold),
                'low_threshold'  => $low_threshold,
            ];

            set_transient($this->cache_key, $kpis, $this->cache_time);
        }

        return $kpis;
    }

    public function clearCache(): void {
        delete_transient($this->cache_key);
    }
}
