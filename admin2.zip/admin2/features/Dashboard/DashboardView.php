<?php
namespace BSC\Admin2\Features\Dashboard;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class DashboardView extends BaseView {
    public function render(array $kpis = []): void {
        ?>
        <div class="wrap bsc-admin-dashboard">
            <h1 style="display:flex;align-items:center;gap:12px">
                BSC Dashboard
                <a href="<?php echo esc_url(add_query_arg('bsc_clear_cache','dashboard')); ?>" class="page-title-action">↺ Actualizar</a>
            </h1>
            <?php
            // Handle cache clear display
            if ( isset($_GET['bsc_clear_cache']) ) {
                echo '<div class="notice notice-success is-dismissible"><p>Caché del dashboard limpiada.</p></div>';
            }
            ?>

            <!-- KPI Cards -->
            <div class="bsc-kpi-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin:16px 0">
                <div class="bsc-kpi-card">
                    <div class="bsc-kpi-value"><?php echo wp_kses_post(wc_price($kpis['ventas_hoy'])); ?></div>
                    <div class="bsc-kpi-label">Ventas hoy</div>
                </div>
                <div class="bsc-kpi-card">
                    <div class="bsc-kpi-value"><?php echo esc_html($kpis['pedidos_hoy']); ?></div>
                    <div class="bsc-kpi-label">Pedidos hoy</div>
                </div>
                <div class="bsc-kpi-card" style="<?php echo $kpis['pendientes'] > 0 ? 'border-color:#f6ad55;background:#fffaf0' : ''; ?>">
                    <div class="bsc-kpi-value"><?php echo esc_html($kpis['pendientes']); ?></div>
                    <div class="bsc-kpi-label">Pendientes</div>
                </div>
                <div class="bsc-kpi-card">
                    <div class="bsc-kpi-value"><?php echo esc_html($kpis['preparando']); ?></div>
                    <div class="bsc-kpi-label">En preparación</div>
                </div>
                <div class="bsc-kpi-card">
                    <div class="bsc-kpi-value"><?php echo esc_html($kpis['enviados']); ?></div>
                    <div class="bsc-kpi-label">Enviados</div>
                </div>
            </div>

            <!-- Bottom panels -->
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:8px">

                <!-- Recent orders -->
                <div>
                    <h2 style="font-size:1rem;margin-bottom:8px">Últimos 5 pedidos</h2>
                    <table class="wp-list-table widefat striped">
                        <thead><tr><th>#</th><th>Cliente</th><th>Total</th><th>Estado</th></tr></thead>
                        <tbody>
                        <?php foreach ($kpis['recent_orders'] as $ro): ?>
                        <tr>
                            <td><a href="<?php echo esc_url($ro['url']); ?>">#<?php echo esc_html($ro['number']); ?></a></td>
                            <td><?php echo esc_html($ro['name']); ?></td>
                            <td><?php echo wp_kses_post(wc_price($ro['total'])); ?></td>
                            <td><?php echo esc_html($ro['status']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($kpis['recent_orders'])): ?><tr><td colspan="4" style="text-align:center;color:#888">Sin pedidos.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                    <p style="margin-top:8px"><a href="<?php echo esc_url(admin_url('admin.php?page=bsc-orders')); ?>" class="button button-primary">Ver todos los pedidos</a></p>
                </div>

                <!-- Low stock alerts -->
                <div>
                    <h2 style="font-size:1rem;margin-bottom:8px">⚠️ Stock bodega bajo (< <?php echo esc_html($kpis['low_threshold']); ?>)</h2>
                    <?php if ( ! empty($kpis['low_stock_ids']) ): ?>
                    <table class="wp-list-table widefat striped" style="background:#fff5f5;border:1px solid #fc8181">
                        <thead><tr><th>Producto</th><th>Stock bodega</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($kpis['low_stock_ids'] as $pid):
                            $stock_b = (int) get_post_meta($pid, '_stock_bodega', true);
                        ?>
                        <tr>
                            <td><?php echo esc_html(get_the_title($pid)); ?></td>
                            <td style="font-weight:700;color:#c53030"><?php echo esc_html($stock_b); ?></td>
                            <td><a href="<?php echo esc_url(admin_url('admin.php?page=bsc-product-edit&id='.$pid)); ?>" class="button button-small">Editar</a></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <p style="color:#276749;background:#f0fff4;border:1px solid #9ae6b4;padding:10px 16px;border-radius:6px">✓ Todos los productos tienen stock suficiente.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <style>
            .bsc-kpi-card { background:#fff; border:1px solid #ddd; border-radius:10px; padding:18px 20px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,0.04); }
            .bsc-kpi-value { font-size:1.8rem; font-weight:800; color:#222; line-height:1.2; }
            .bsc-kpi-label { font-size:0.78rem; color:#888; margin-top:4px; font-weight:600; letter-spacing:0.5px; text-transform:uppercase; }
        </style>
        <?php
    }
}
