<?php
namespace BSC\Admin2\Features\Dashboard;

defined('ABSPATH') || exit;

class DashboardRepo {
    public function getTodaySalesAndOrdersCount(): array {
        $today_start = gmdate('Y-m-d') . ' 00:00:00';
        $today_end   = gmdate('Y-m-d') . ' 23:59:59';

        $today_orders = wc_get_orders([
            'date_after'  => $today_start,
            'date_before' => $today_end,
            'limit'       => -1,
            'return'      => 'objects',
        ]);

        $ventas_hoy = array_reduce($today_orders, function($carry, $o) {
            return $carry + (in_array($o->get_status(), ['processing','completed','preparing','shipped']) ? (float)$o->get_total() : 0);
        }, 0);

        return [
            'ventas_hoy'  => $ventas_hoy,
            'pedidos_hoy' => count($today_orders),
        ];
    }

    public function getStatusCounts(): array {
        $pending_ids    = wc_get_orders(['status' => ['pending','on-hold'], 'limit' => -1, 'return' => 'ids']);
        $preparing_ids  = wc_get_orders(['status' => ['processing','wc-preparing'], 'limit' => -1, 'return' => 'ids']);
        $shipped_ids    = wc_get_orders(['status' => ['wc-shipped'], 'limit' => -1, 'return' => 'ids']);

        return [
            'pendientes' => count($pending_ids),
            'preparando' => count($preparing_ids),
            'enviados'   => count($shipped_ids),
        ];
    }

    public function getRecentOrders(int $limit = 5): array {
        $recent_orders = wc_get_orders(['limit' => $limit, 'orderby' => 'date', 'order' => 'DESC']);
        return array_map(fn($o) => [
            'id'     => $o->get_id(),
            'number' => $o->get_order_number(),
            'name'   => $o->get_formatted_billing_full_name(),
            'total'  => (float) $o->get_total(),
            'status' => wc_get_order_status_name($o->get_status()),
            'url'    => $o->get_edit_order_url(),
        ], $recent_orders);
    }

    public function getLowStockProducts(int $threshold): array {
        return class_exists('\BSC_Stock') ? \BSC_Stock::get_low_stock_products($threshold) : [];
    }
}
