<?php
namespace BSC\Admin2\Features\Orders;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class OrdersView extends BaseView {

    public function render(array $data = []): void {
        $status_tabs = $data['status_tabs'] ?? [];
        $tab_counts  = $data['tab_counts'] ?? [];
        $active_status = $data['active_status'] ?? '';
        $date_start  = $data['date_start'] ?? '';
        $date_end    = $data['date_end'] ?? '';
        $search      = $data['search'] ?? '';
        $table       = $data['table'] ?? null;

        $base_url = admin_url( 'admin.php?page=bsc-orders' );
        ?>
        <div class="wrap bsc-admin-orders">
            <h1 class="wp-heading-inline">Pedidos BSC</h1>
            <hr class="wp-header-end">

            <!-- ── Status tabs ── -->
            <nav class="bsc-orders-tabs">
                <?php foreach ( $status_tabs as $slug => $label ) :
                    $tab_url = $slug
                        ? add_query_arg( 'order_status', $slug, $base_url )
                        : $base_url;
                    $is_active = ( $active_status === $slug );
                    $count = $tab_counts[ $slug ] ?? 0;
                ?>
                <a href="<?php echo esc_url( $tab_url ); ?>"
                   class="bsc-orders-tab<?php echo $is_active ? ' bsc-orders-tab--active' : ''; ?>">
                    <?php echo esc_html( $label ); ?>
                    <span class="bsc-tab-count"><?php echo esc_html( $count ); ?></span>
                </a>
                <?php endforeach; ?>
            </nav>

            <!-- ── Filters ── -->
            <form method="get" class="bsc-orders-filters">
                <input type="hidden" name="page" value="bsc-orders">
                <?php if ( $active_status ) : ?>
                <input type="hidden" name="order_status" value="<?php echo esc_attr( $active_status ); ?>">
                <?php endif; ?>
                <div>
                    <label>Desde</label>
                    <input type="date" name="date_start" value="<?php echo esc_attr( $date_start ); ?>">
                </div>
                <div>
                    <label>Hasta</label>
                    <input type="date" name="date_end" value="<?php echo esc_attr( $date_end ); ?>">
                </div>
                <div>
                    <label>Buscar</label>
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>"
                           placeholder="Nombre, email o # de orden" style="width:220px">
                </div>
                <button type="submit" class="button button-primary">Filtrar</button>
                <?php if ( $date_start || $date_end || $search ) : ?>
                    <a href="<?php echo esc_url( $active_status ? add_query_arg('order_status', $active_status, $base_url) : $base_url ); ?>" class="button">Limpiar</a>
                <?php endif; ?>
            </form>

            <!-- ── Table with bulk export form ── -->
            <form method="post" id="bsc-orders-form"
                  action="<?php echo esc_url( admin_url( 'admin.php?page=bsc-orders' ) ); ?>">
                <?php wp_nonce_field( 'bsc_bulk_export', 'bsc_export_nonce' ); ?>
                <div style="margin-bottom:10px;display:flex;gap:8px;align-items:center">
                    <button type="submit" name="bsc_bulk_action" value="export_csv" class="button" id="bsc-csv-btn">
                        ⬇ Exportar CSV
                    </button>
                    <button type="submit" name="bsc_bulk_action" value="print_packing" class="button" id="bsc-packing-btn">
                        🖨 Vista de empaque
                    </button>
                    <span id="bsc-bulk-msg" style="display:none;color:#c0392b;font-size:13px;margin-left:6px">
                        Selecciona al menos un pedido primero.
                    </span>
                </div>
                <?php if ($table) $table->display(); ?>
            </form>

            <script>
            (function($){
                function requireSelection(e) {
                    if ($('input[name="order_ids[]"]:checked').length === 0) {
                        e.preventDefault();
                        $('#bsc-bulk-msg').stop(true).fadeIn(150).delay(3000).fadeOut(400);
                        return false;
                    }
                    return true;
                }

                $('#bsc-packing-btn').on('click', function(e) {
                    if (!requireSelection(e)) return;
                    $('#bsc-orders-form').attr('target', '_blank');
                    setTimeout(function() { $('#bsc-orders-form').removeAttr('target'); }, 300);
                });

                $('#bsc-csv-btn').on('click', function(e) {
                    if (!requireSelection(e)) return;
                    $('#bsc-orders-form').removeAttr('target');
                });
            })(jQuery);
            </script>
        </div>

        <style>
            .bsc-orders-tabs { display:flex; gap:2px; flex-wrap:wrap; margin:16px 0 0; border-bottom:2px solid #ddd; }
            .bsc-orders-tab {
                display:inline-flex; align-items:center; gap:6px;
                padding:8px 14px; font-size:13px; color:#555; text-decoration:none;
                border:1px solid transparent; border-bottom:none; border-radius:4px 4px 0 0;
                margin-bottom:-2px; background:#f9f9f9;
            }
            .bsc-orders-tab:hover { background:#fff; color:#333; }
            .bsc-orders-tab--active { background:#fff; color:#000; font-weight:600; border-color:#ddd; border-bottom-color:#fff; }
            .bsc-tab-count { background:#e1e1e1; color:#555; border-radius:10px; padding:1px 7px; font-size:11px; font-weight:700; }
            .bsc-orders-tab--active .bsc-tab-count { background:#2271b1; color:#fff; }

            .bsc-orders-filters { margin:12px 0 16px; display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap; }
            .bsc-orders-filters label { display:block; font-size:11px; font-weight:600; margin-bottom:3px; text-transform:uppercase; letter-spacing:.3px; color:#555; }
            .bsc-orders-filters input[type=date], .bsc-orders-filters input[type=search] { padding:5px; }

            .bsc-admin-orders .wp-list-table { font-size:13px; }
            .bsc-admin-orders .column-tracking input { margin-bottom:4px; }
            .bsc-admin-orders .column-city { width:90px; }
            .bsc-admin-orders .column-status { width:170px; }
        </style>
        <?php
    }
}
