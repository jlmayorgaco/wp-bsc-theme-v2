<?php
namespace BSC\Admin2\Features\Orders;

defined('ABSPATH') || exit;

class OrdersFeature {

    public function register(): void {
        add_action('admin_init', [$this, 'handleBulkExport']);
        add_action('wp_ajax_bsc_update_order_status', [$this, 'ajaxUpdateOrderStatus']);
        add_action('wp_ajax_bsc_save_tracking', [$this, 'ajaxSaveTracking']);
    }

    public function handleBulkExport(): void {
        if ( ! isset( $_POST['bsc_bulk_action'], $_POST['bsc_export_nonce'] ) ) return;
        if ( ( sanitize_text_field( $_GET['page'] ?? '' ) ) !== 'bsc-orders' ) return;

        if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bsc_export_nonce'] ) ), 'bsc_bulk_export' ) ) {
            wp_die( esc_html__( 'Nonce inválido.', 'bsc-2-0' ) );
        }
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_orders' ) ) {
            wp_die( esc_html__( 'Sin permisos.', 'bsc-2-0' ) );
        }

        $action    = sanitize_text_field( $_POST['bsc_bulk_action'] );
        $order_ids = array_map( 'absint', (array) ( $_POST['order_ids'] ?? [] ) );

        if ( empty( $order_ids ) ) return;

        $service = new OrdersService();

        if ( $action === 'export_csv' ) {
            $service->exportOrdersCsv( $order_ids );
        } elseif ( $action === 'print_packing' ) {
            $service->renderPackingView( $order_ids );
        }
    }

    public function ajaxUpdateOrderStatus(): void {
        check_ajax_referer( 'bsc_admin_orders', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_orders' ) ) wp_send_json_error( ['message' => 'Sin permisos'] );

        $order_id = absint( $_POST['order_id'] ?? 0 );
        $status   = sanitize_text_field( $_POST['status'] ?? '' );

        $status = preg_replace( '/^wc-/', '', $status );

        $order = wc_get_order( $order_id );
        if ( ! $order ) wp_send_json_error( ['message' => 'Pedido no encontrado'] );

        $order->update_status( $status, 'Estado actualizado desde BSC Admin.' );
        wp_send_json_success( ['message' => 'Estado actualizado', 'status' => $status] );
    }

    public function ajaxSaveTracking(): void {
        check_ajax_referer( 'bsc_admin_orders', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_orders' ) ) wp_send_json_error( ['message' => 'Sin permisos'] );

        $order_id      = absint( $_POST['order_id'] ?? 0 );
        $tracking_code = sanitize_text_field( $_POST['tracking_code'] ?? '' );
        $tracking_link = esc_url_raw( $_POST['tracking_link'] ?? '' );

        $order = wc_get_order( $order_id );
        if ( ! $order ) wp_send_json_error( ['message' => 'Pedido no encontrado'] );

        update_post_meta( $order_id, '_bsc_tracking_code', $tracking_code );
        update_post_meta( $order_id, '_bsc_tracking_link', $tracking_link );

        if ( $tracking_code && $order->get_status() !== 'shipped' ) {
            $order->update_status( 'shipped', 'Guía ingresada desde BSC Admin.' );

            $service = new OrdersService();
            $email_error = $service->sendShippingEmail( $order_id );
            if ( $email_error ) {
                error_log( 'BSC: error al enviar email de envío — ' . $email_error );
            }
        }

        wp_send_json_success( ['message' => 'Tracking guardado'] );
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_orders' ) ) {
            wp_die( esc_html__( 'No tienes permisos.', 'bsc-2-0' ) );
        }

        $repo = new OrdersRepo();

        $date_start     = isset( $_GET['date_start'] )    ? sanitize_text_field( $_GET['date_start'] )    : '';
        $date_end       = isset( $_GET['date_end'] )      ? sanitize_text_field( $_GET['date_end'] )      : '';
        $search         = isset( $_GET['s'] )             ? sanitize_text_field( $_GET['s'] )             : '';
        $active_status  = isset( $_GET['order_status'] )  ? sanitize_text_field( $_GET['order_status'] )  : '';

        $query_args = [];
        if ( $date_start )    $query_args['date_after']  = $date_start . ' 00:00:00';
        if ( $date_end )      $query_args['date_before'] = $date_end   . ' 23:59:59';
        if ( $search )        $query_args['s']           = $search;
        if ( $active_status ) $query_args['status']      = [ $active_status ];

        $table = new OrdersTable( $query_args );
        $table->prepare_items();

        $view = new OrdersView();
        $view->render([
            'status_tabs'   => $repo->getStatusTabs(),
            'tab_counts'    => $repo->getTabCounts(),
            'active_status' => $active_status,
            'date_start'    => $date_start,
            'date_end'      => $date_end,
            'search'        => $search,
            'table'         => $table,
        ]);
    }
}
