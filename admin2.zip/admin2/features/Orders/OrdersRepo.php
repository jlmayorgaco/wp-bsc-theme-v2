<?php
namespace BSC\Admin2\Features\Orders;

defined('ABSPATH') || exit;

class OrdersRepo {
    public function getStatusTabs(): array {
        return [
            ''             => 'Todos',
            'pending'      => 'Pendiente',
            'processing'   => 'Procesando',
            'wc-preparing' => 'Preparando',
            'wc-shipped'   => 'Enviado',
            'completed'    => 'Completado',
            'cancelled'    => 'Cancelado',
        ];
    }

    public function getTabCounts(): array {
        $tabs = $this->getStatusTabs();
        $counts = [];

        foreach ( $tabs as $slug => $label ) {
            if ( $slug === '' ) {
                $status_values = array_values( array_filter( array_keys( $tabs ) ) );
                $counts[$slug] = count( wc_get_orders( [ 'limit' => -1, 'return' => 'ids', 'status' => $status_values ] ) );
            } else {
                $counts[$slug] = count( wc_get_orders( [ 'limit' => -1, 'return' => 'ids', 'status' => [ $slug ] ] ) );
            }
        }

        return $counts;
    }
}
