<?php
namespace BSC\Admin2\Features\Orders;

defined('ABSPATH') || exit;

class OrdersService {

    public function sendShippingEmail( int $order_id ): string {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return 'Pedido no encontrado';

        $to    = $order->get_billing_email();
        if ( ! $to ) return 'Sin email del cliente';

        $tracking_code = get_post_meta( $order_id, '_bsc_tracking_code', true );
        $tracking_link = get_post_meta( $order_id, '_bsc_tracking_link', true );

        $subject = sprintf( 'Tu pedido #%s está en camino 🚚', $order->get_order_number() );

        ob_start();
        include get_template_directory() . '/emails/bsc-order-shipped.php';
        $message = ob_get_clean();

        $sent = wp_mail(
            $to,
            $subject,
            $message,
            [ 'Content-Type: text/html; charset=UTF-8' ]
        );

        return $sent ? '' : 'wp_mail() devolvió false';
    }

    public function exportOrdersCsv( array $order_ids ): void {
        while ( ob_get_level() > 0 ) {
            ob_end_clean();
        }

        $bom = "\xEF\xBB\xBF";

        header( 'Content-Type: text/csv; charset=UTF-8' );
        header( 'Content-Disposition: attachment; filename="pedidos-' . gmdate('Y-m-d') . '.csv"' );
        header( 'Pragma: no-cache' );
        header( 'Expires: 0' );

        $out = fopen( 'php://output', 'w' );
        fwrite( $out, $bom );

        fputcsv( $out, [ 'ID', 'Fecha', 'Cliente', 'Email', 'Teléfono', 'Ciudad', 'Dirección', 'Productos', 'Total', 'Estado' ] );

        foreach ( $order_ids as $id ) {
            $order = wc_get_order( $id );
            if ( ! $order ) continue;

            $items = [];
            foreach ( $order->get_items() as $item ) {
                $items[] = $item->get_quantity() . '× ' . $item->get_name();
            }

            fputcsv( $out, [
                $order->get_order_number(),
                $order->get_date_created() ? $order->get_date_created()->date('d/m/Y H:i') : '',
                trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
                $order->get_billing_email(),
                $order->get_billing_phone(),
                $order->get_shipping_city() ?: $order->get_billing_city(),
                trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() ) ?: $order->get_billing_address_1(),
                implode( ' | ', $items ),
                $order->get_total(),
                wc_get_order_status_name( $order->get_status() ),
            ] );
        }

        fclose( $out );
        exit;
    }

    public function renderPackingView( array $order_ids ): void {
        while ( ob_get_level() > 0 ) {
            ob_end_clean();
        }
        header( 'Content-Type: text/html; charset=UTF-8' );
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Vista de Empaque — BSC</title>
            <style>
                * { box-sizing: border-box; }
                body { font-family: Arial, sans-serif; font-size: 13px; color: #222; margin: 0; padding: 16px; }
                h1 { font-size: 18px; margin: 0 0 16px; }
                .order-card { border: 1px solid #ccc; border-radius: 8px; padding: 16px; margin-bottom: 20px; page-break-inside: avoid; }
                .order-header { display: flex; justify-content: space-between; margin-bottom: 10px; }
                .order-number { font-size: 16px; font-weight: bold; }
                .order-status { background: #FFB6C1; color: #000; padding: 3px 10px; border-radius: 20px; font-size: 12px; }
                .order-details { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px; font-size: 12px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { padding: 6px 8px; text-align: left; border-bottom: 1px solid #eee; font-size: 12px; }
                th { background: #f5f5f5; font-weight: bold; }
                .total-row td { font-weight: bold; border-top: 2px solid #ccc; }
                @media print {
                    body { padding: 8px; }
                    .no-print { display: none; }
                    .order-card { border: 1px solid #999; }
                }
            </style>
        </head>
        <body>
            <div class="no-print" style="margin-bottom:16px">
                <button onclick="window.print()" style="padding:8px 16px;cursor:pointer">🖨 Imprimir</button>
                <button onclick="window.close()" style="padding:8px 16px;margin-left:8px;cursor:pointer">✕ Cerrar</button>
            </div>
            <h1>Vista de Empaque — <?php echo esc_html( gmdate('d/m/Y') ); ?></h1>

            <?php foreach ( $order_ids as $id ) :
                $order = wc_get_order( $id );
                if ( ! $order ) continue;
                $name = trim( $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name() )
                     ?: trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
                $city    = $order->get_shipping_city() ?: $order->get_billing_city();
                $address = trim( $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() )
                        ?: $order->get_billing_address_1();
            ?>
            <div class="order-card">
                <div class="order-header">
                    <span class="order-number">#<?php echo esc_html( $order->get_order_number() ); ?></span>
                    <span class="order-status"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
                </div>
                <div class="order-details">
                    <div><strong>Cliente:</strong> <?php echo esc_html( $name ); ?></div>
                    <div><strong>Teléfono:</strong> <?php echo esc_html( $order->get_billing_phone() ); ?></div>
                    <div><strong>Ciudad:</strong> <?php echo esc_html( $city ); ?></div>
                    <div><strong>Fecha:</strong> <?php echo esc_html( $order->get_date_created() ? $order->get_date_created()->date('d/m/Y') : '' ); ?></div>
                    <div style="grid-column:span 2"><strong>Dirección:</strong> <?php echo esc_html( $address ); ?></div>
                </div>
                <table>
                    <thead>
                        <tr><th>Producto</th><th>SKU</th><th>Qty</th><th>Subtotal</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $order->get_items() as $item ) :
                            $product = $item->get_product();
                            $sku     = $product ? $product->get_sku() : '';
                        ?>
                        <tr>
                            <td><?php echo esc_html( $item->get_name() ); ?></td>
                            <td><?php echo esc_html( $sku ); ?></td>
                            <td><?php echo esc_html( $item->get_quantity() ); ?></td>
                            <td><?php echo wp_kses_post( wc_price( $item->get_total() ) ); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr class="total-row">
                            <td colspan="3">Total</td>
                            <td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <?php endforeach; ?>
        </body>
        </html>
        <?php
        exit;
    }
}
