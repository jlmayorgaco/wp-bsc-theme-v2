<?php
namespace BSC\Admin2\Features\Reports;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class ReportsView extends BaseView {
    public function render(array $data = []): void {
        $tabs       = $data['tabs'];
        $active_tab = $data['active_tab'];

        echo '<div class="wrap bsc-admin-reports">';
        echo '<h1>Informes BSC</h1>';

        echo '<nav class="nav-tab-wrapper" style="margin-bottom:0">';
        foreach ($tabs as $slug => $tab) {
            $url   = esc_url(add_query_arg(['page' => 'bsc-reports', 'tab' => $slug], admin_url('admin.php')));
            $class = $slug === $active_tab ? 'nav-tab nav-tab-active' : 'nav-tab';
            printf('<a href="%s" class="%s">%s</a>', $url, esc_attr($class), esc_html($tab['label']));
        }
        echo '</nav>';

        echo '<div class="bsc-tab-content" style="background:#fff;border:1px solid #c3c4c7;border-top:none;padding:20px 24px;margin-bottom:20px">';

        if (is_callable($tabs[$active_tab]['callback'])) {
            call_user_func($tabs[$active_tab]['callback'], $data);
        } else {
            echo '<p style="color:#888">Tab no disponible.</p>';
        }

        echo '</div></div>';

        echo '<style>
            .bsc-kpi-grid  { display:flex; gap:12px; flex-wrap:wrap; margin:16px 0; }
            .bsc-kpi-card  { background:#f9f9f9; border:1px solid #ddd; border-radius:8px; padding:16px 20px; min-width:130px; text-align:center; }
            .bsc-kpi-value { font-size:1.5rem; font-weight:800; color:#222; line-height:1.2; }
            .bsc-kpi-label { font-size:0.75rem; color:#888; margin-top:4px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; }
        </style>';
    }

    public function renderVentasTab(array $data): void {
        extract($data['ventas_data']);

        $export_nonce = wp_create_nonce('bsc_reports_export');
        $export_url   = add_query_arg([
            'page'=>'bsc-reports','tab'=>'ventas','bsc_export_csv'=>1,
            'bsc_export_nonce'=>$export_nonce,'date_start'=>$date_start,
            'date_end'=>$date_end,'statuses'=>$statuses,
        ], admin_url('admin.php'));
        ?>

        <!-- Filters -->
        <form method="get" style="background:#f9f9f9;border:1px solid #ddd;border-radius:6px;padding:14px 16px;margin-bottom:16px">
            <input type="hidden" name="page"  value="bsc-reports">
            <input type="hidden" name="tab"   value="ventas">
            <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px">Desde</label>
                    <input type="date" name="date_start" value="<?php echo esc_attr($date_start); ?>" style="padding:5px">
                </div>
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px">Hasta</label>
                    <input type="date" name="date_end" value="<?php echo esc_attr($date_end); ?>" style="padding:5px">
                </div>
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;margin-bottom:3px">Estado</label>
                    <div style="display:flex;gap:8px">
                        <?php foreach (['completed'=>'Completado','processing'=>'Procesando','wc-preparing'=>'Preparando','wc-shipped'=>'Enviado'] as $slug => $label): ?>
                        <label style="font-size:12px">
                            <input type="checkbox" name="statuses[]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug,$statuses)); ?>>
                            <?php echo esc_html($label); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                    <button type="submit" class="button button-primary">Aplicar</button>
                    <?php foreach (['hoy'=>'Hoy','semana'=>'Semana','mes'=>'Este mes','mes_ant'=>'Mes ant.','anno'=>'Este año'] as $k=>$l): ?>
                    <a href="<?php echo esc_url(add_query_arg(['page'=>'bsc-reports','tab'=>'ventas','preset'=>$k])); ?>" class="button"><?php echo esc_html($l); ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        </form>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <span style="color:#666;font-size:13px">
                <?php echo esc_html($date_start); ?> → <?php echo esc_html($date_end); ?>
                &nbsp;|&nbsp;
                <a href="<?php echo esc_url(add_query_arg(['tab'=>'ventas','bsc_clear_report_cache'=>'1'])); ?>">↺ Limpiar caché</a>
            </span>
            <a href="<?php echo esc_url($export_url); ?>" class="button">⬇ Exportar CSV</a>
        </div>

        <div class="bsc-kpi-grid">
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo wp_kses_post(wc_price($total_sales)); ?></div><div class="bsc-kpi-label">Ventas totales</div></div>
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo esc_html($order_count); ?></div><div class="bsc-kpi-label">Pedidos</div></div>
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo wp_kses_post(wc_price($avg_ticket)); ?></div><div class="bsc-kpi-label">Ticket promedio</div></div>
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo esc_html($avg_items); ?></div><div class="bsc-kpi-label">Ítems / pedido</div></div>
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo wp_kses_post(wc_price($web_sales)); ?></div><div class="bsc-kpi-label">Ventas Web</div></div>
            <div class="bsc-kpi-card"><div class="bsc-kpi-value"><?php echo wp_kses_post(wc_price($showroom_sales)); ?></div><div class="bsc-kpi-label">Ventas Showroom</div></div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:20px">
            <div>
                <h2 style="font-size:1rem;margin-bottom:8px">Top 10 productos vendidos</h2>
                <?php if ($top_products): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead><tr><th>#</th><th>Producto</th><th>Uds.</th><th>Total</th></tr></thead>
                    <tbody>
                    <?php $rank=1; foreach ($top_products as $pid => $p): ?>
                    <tr>
                        <td><?php echo esc_html($rank++); ?></td>
                        <td><a href="<?php echo esc_url(get_edit_post_link($pid)); ?>" target="_blank"><?php echo esc_html($p['name']); ?></a></td>
                        <td><?php echo esc_html($p['qty']); ?></td>
                        <td><?php echo wp_kses_post(wc_price($p['total'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><p style="color:#888">Sin ventas en el período.</p><?php endif; ?>
            </div>
            <div>
                <h2 style="font-size:1rem;margin-bottom:8px">Desglose por categoría</h2>
                <?php if ($category_sales): ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead><tr><th>Categoría</th><th>Pedidos</th><th>Total</th></tr></thead>
                    <tbody>
                    <?php foreach (array_slice($category_sales, 0, 10, true) as $tid => $cat): ?>
                    <tr>
                        <td><?php echo esc_html($cat['name']); ?></td>
                        <td><?php echo esc_html($cat['orders']); ?></td>
                        <td><?php echo wp_kses_post(wc_price($cat['total'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?><p style="color:#888">Sin datos de categorías.</p><?php endif; ?>
            </div>
        </div>

        <p style="margin-top:1.5rem;color:#888;font-size:12px">Resultados cacheados por 1 hora. Use ↺ Limpiar caché para actualizar.</p>
        <?php
    }

    public function renderStockTab(array $data): void {
        extract($data['stock_data']);
        ?>

        <!-- KPI summary -->
        <div class="bsc-kpi-grid">
            <div class="bsc-kpi-card">
                <div class="bsc-kpi-value"><?php echo esc_html($totals['total_products'] ?? 0); ?></div>
                <div class="bsc-kpi-label">Productos</div>
            </div>
            <div class="bsc-kpi-card">
                <div class="bsc-kpi-value"><?php echo esc_html($totals['sum_bodega'] ?? 0); ?></div>
                <div class="bsc-kpi-label">Total Bodega</div>
            </div>
            <div class="bsc-kpi-card">
                <div class="bsc-kpi-value"><?php echo esc_html($totals['sum_tienda'] ?? 0); ?></div>
                <div class="bsc-kpi-label">Total Showcase</div>
            </div>
            <div class="bsc-kpi-card" style="<?php echo ($totals['low_bodega_count'] ?? 0) > 0 ? 'border-color:#f6ad55;background:#fffaf0' : ''; ?>">
                <div class="bsc-kpi-value" style="<?php echo ($totals['low_bodega_count'] ?? 0) > 0 ? 'color:#c05621' : ''; ?>">
                    <?php echo esc_html($totals['low_bodega_count'] ?? 0); ?>
                </div>
                <div class="bsc-kpi-label">Stock bodega bajo</div>
            </div>
            <div class="bsc-kpi-card" style="<?php echo ($totals['zero_bodega_count'] ?? 0) > 0 ? 'border-color:#fc8181;background:#fff5f5' : ''; ?>">
                <div class="bsc-kpi-value" style="<?php echo ($totals['zero_bodega_count'] ?? 0) > 0 ? 'color:#c53030' : ''; ?>">
                    <?php echo esc_html($totals['zero_bodega_count'] ?? 0); ?>
                </div>
                <div class="bsc-kpi-label">Sin stock bodega</div>
            </div>
            <div class="bsc-kpi-card" style="color:#666">
                <div class="bsc-kpi-value" style="font-size:1rem;color:#555"><?php echo esc_html($threshold); ?></div>
                <div class="bsc-kpi-label">Umbral alerta</div>
            </div>
        </div>

        <!-- Filter + search bar -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin:12px 0 10px;flex-wrap:wrap;gap:8px">
            <div style="display:flex;gap:6px;flex-wrap:wrap">
                <?php foreach ($filter_links as $fkey => $flabel): ?>
                <?php $furl = esc_url(add_query_arg(['page'=>'bsc-reports','tab'=>'stock','sort'=>$sort_col,'dir'=>strtolower($sort_dir),'stock_filter'=>$fkey], admin_url('admin.php'))); ?>
                <a href="<?php echo $furl; ?>"
                   class="button<?php echo $filter === $fkey ? ' button-primary' : ''; ?>"
                   style="font-size:12px">
                    <?php echo esc_html($flabel); ?>
                </a>
                <?php endforeach; ?>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
                <input type="text" id="bsc-stock-search" placeholder="Buscar producto o SKU…"
                       style="padding:5px 8px;border:1px solid #ccc;border-radius:3px;width:220px;font-size:13px">
                <span id="bsc-stock-count" style="font-size:12px;color:#888"></span>
            </div>
        </div>

        <!-- Legend -->
        <p style="font-size:11px;color:#888;margin-bottom:8px">
            <span style="background:#fff5f5;padding:2px 6px;border-radius:3px;margin-right:6px">Sin stock</span>
            <span style="background:#fffbeb;padding:2px 6px;border-radius:3px;margin-right:6px">Un tipo vacío</span>
            <span style="background:#fffff0;padding:2px 6px;border-radius:3px;margin-right:6px">Stock bajo (&lt; <?php echo esc_html($threshold); ?>)</span>
            <a href="<?php echo esc_url(admin_url('admin.php?page=bsc-settings')); ?>" style="font-size:11px;color:#888">Cambiar umbral ↗</a>
        </p>

        <?php if (empty($products)): ?>
        <p style="color:#888;font-style:italic">No hay productos que coincidan con el filtro.</p>
        <?php else: ?>
        <table id="bsc-stock-table" class="wp-list-table widefat fixed striped" style="font-size:13px">
            <thead>
                <tr>
                    <th style="width:35%">
                        <a href="<?php echo $sort_link('title'); ?>">Producto <?php echo $sort_arrow('title'); ?></a>
                    </th>
                    <th style="width:13%">
                        <a href="<?php echo $sort_link('sku'); ?>">SKU <?php echo $sort_arrow('sku'); ?></a>
                    </th>
                    <th style="width:13%;text-align:center">
                        <a href="<?php echo $sort_link('bodega'); ?>">Bodega <?php echo $sort_arrow('bodega'); ?></a>
                    </th>
                    <th style="width:13%;text-align:center">
                        <a href="<?php echo $sort_link('tienda'); ?>">Showcase <?php echo $sort_arrow('tienda'); ?></a>
                    </th>
                    <th style="width:10%;text-align:center">
                        <a href="<?php echo $sort_link('total'); ?>">Total <?php echo $sort_arrow('total'); ?></a>
                    </th>
                    <th style="width:10%;text-align:center">Despacho</th>
                    <th style="width:6%"></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($products as $row):
                $b       = (int) $row->stock_bodega;
                $t       = (int) $row->stock_tienda;
                $edit_url = admin_url('admin.php?page=bsc-product-edit&id=' . $row->ID);
                $b_style = $b === 0 ? 'color:#c53030;font-weight:700' : ($b < $threshold ? 'color:#c05621;font-weight:600' : '');
                $t_style = $t === 0 ? 'color:#c53030;font-weight:700' : ($t < $threshold ? 'color:#c05621;font-weight:600' : '');
                $envio_labels = ['bodega'=>'Bodega','tienda'=>'Showcase','ambos'=>'Ambos'];
                ?>
                <tr style="<?php echo esc_attr($row_style($row)); ?>" class="bsc-stock-row">
                    <td>
                        <a href="<?php echo esc_url($edit_url); ?>"><?php echo esc_html($row->post_title); ?></a>
                    </td>
                    <td style="color:#666;font-size:12px"><?php echo esc_html($row->sku); ?></td>
                    <td style="text-align:center;<?php echo esc_attr($b_style); ?>"><?php echo esc_html($b); ?></td>
                    <td style="text-align:center;<?php echo esc_attr($t_style); ?>"><?php echo esc_html($t); ?></td>
                    <td style="text-align:center;font-weight:600"><?php echo esc_html((int)$row->stock_total); ?></td>
                    <td style="text-align:center;font-size:12px;color:#555">
                        <?php echo esc_html($envio_labels[$row->envio_tipo] ?? $row->envio_tipo); ?>
                    </td>
                    <td>
                        <a href="<?php echo esc_url($edit_url); ?>" class="button button-small">Editar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p style="color:#888;font-size:12px;margin-top:8px">
            <?php echo esc_html(count($products)); ?> producto(s) mostrados.
        </p>
        <?php endif; ?>

        <script>
        (function() {
            var searchInput = document.getElementById('bsc-stock-search');
            var countEl     = document.getElementById('bsc-stock-count');
            if (!searchInput) return;

            searchInput.addEventListener('input', function() {
                var q    = this.value.toLowerCase().trim();
                var rows = document.querySelectorAll('#bsc-stock-table .bsc-stock-row');
                var vis  = 0;
                rows.forEach(function(row) {
                    var text = row.textContent.toLowerCase();
                    var show = !q || text.indexOf(q) !== -1;
                    row.style.display = show ? '' : 'none';
                    if (show) vis++;
                });
                countEl.textContent = q ? vis + ' resultado(s)' : '';
            });
        })();
        </script>
        <?php
    }
}
