<?php
namespace BSC\Admin2\Features\Reports;

defined('ABSPATH') || exit;

class ReportsFeature {
    public function getTabs(): array {
        return [
            'ventas' => ['label' => 'Ventas',  'callback' => [$this, 'getVentasData']],
            'stock'  => ['label' => 'Stock',   'callback' => [$this, 'getStockData']],
        ];
    }

    public function handleCsvExport(): void {
        if (!isset($_GET['page']) || $_GET['page'] !== 'bsc-reports') return;
        if (!isset($_GET['bsc_export_csv'])) return;
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) wp_die('Sin permisos.');
        if (!wp_verify_nonce(sanitize_text_field($_GET['bsc_export_nonce'] ?? ''), 'bsc_reports_export')) wp_die('Nonce inválido.');

        $date_start = sanitize_text_field($_GET['date_start'] ?? gmdate('Y-m-01'));
        $date_end   = sanitize_text_field($_GET['date_end']   ?? gmdate('Y-m-d'));
        
        $repo = new ReportsRepo();
        $statuses = $repo->getStatuses();
        $orders   = $repo->getOrdersForPeriod($date_start, $date_end, $statuses);

        while (ob_get_level() > 0) ob_end_clean();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="bsc-informe-' . $date_start . '_' . $date_end . '.csv"');
        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Fecha', 'Pedido #', 'Cliente', 'Email', 'Productos', 'Total', 'Estado', 'Canal']);

        foreach ($orders as $order) {
            $items_str = implode(' | ', array_map(fn($i) => $i->get_name() . ' x' . $i->get_quantity(), $order->get_items()));
            $canal     = $order->get_meta('_bsc_is_showroom_sale') ? 'Showroom' : 'Web';
            fputcsv($out, [
                $order->get_date_created()?->date('Y-m-d H:i') ?? '',
                '#' . $order->get_order_number(),
                $order->get_formatted_billing_full_name(),
                $order->get_billing_email(),
                $items_str,
                $order->get_total(),
                wc_get_order_status_name($order->get_status()),
                $canal,
            ]);
        }
        fclose($out);
        exit;
    }

    public function render(): void {
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'bsc-2-0'));
        }

        $tabs       = $this->getTabs();
        $active_tab = sanitize_key($_GET['tab'] ?? 'ventas');
        if (!isset($tabs[$active_tab])) {
            $active_tab = 'ventas';
        }

        $view = new ReportsView();

        if (is_callable($tabs[$active_tab]['callback'])) {
            $tabData = call_user_func($tabs[$active_tab]['callback']);
            
            $data = [
                'tabs'         => function() use ($tabs) {
                    $viewableTabs = [];
                    foreach ($tabs as $k => $v) {
                        $viewableTabs[$k] = [
                            'label' => $v['label'],
                            'callback' => [$view, $k === 'ventas' ? 'renderVentasTab' : 'renderStockTab']
                        ];
                    }
                    return $viewableTabs;
                }(),
                'active_tab'   => $active_tab,
                $active_tab . '_data' => $tabData,
            ];
            $view->render($data);
        } else {
            $view->render(['tabs' => [], 'active_tab' => '']);
        }
    }

    public function getVentasData(): array {
        $date_start = sanitize_text_field($_GET['date_start'] ?? gmdate('Y-m-01'));
        $date_end   = sanitize_text_field($_GET['date_end']   ?? gmdate('Y-m-d'));

        if (isset($_GET['preset'])) {
            switch ($_GET['preset']) {
                case 'hoy':     $date_start = $date_end = gmdate('Y-m-d'); break;
                case 'semana':  $date_start = gmdate('Y-m-d', strtotime('monday this week')); $date_end = gmdate('Y-m-d'); break;
                case 'mes':     $date_start = gmdate('Y-m-01'); $date_end = gmdate('Y-m-d'); break;
                case 'mes_ant': $date_start = gmdate('Y-m-01', strtotime('first day of last month')); $date_end = gmdate('Y-m-t', strtotime('last month')); break;
                case 'anno':    $date_start = gmdate('Y-01-01'); $date_end = gmdate('Y-m-d'); break;
            }
        }

        $repo = new ReportsRepo();
        $statuses = $repo->getStatuses();

        $cache_key = 'bsc_report_' . md5($date_start . '_' . $date_end . implode(',', $statuses));
        $data = get_transient($cache_key);

        if (isset($_GET['bsc_clear_report_cache'])) {
            delete_transient($cache_key);
            $data = false;
        }

        if (false === $data || !is_array($data)) {
            $orders = $repo->getOrdersForPeriod($date_start, $date_end, $statuses);

            $total_sales    = 0; $order_count = count($orders);
            $total_items    = 0; $web_sales   = 0; $showroom_sales = 0;
            $product_sales  = []; $category_sales = [];

            foreach ($orders as $order) {
                $total = (float) $order->get_total();
                $total_sales += $total;
                $is_showroom  = (bool) $order->get_meta('_bsc_is_showroom_sale');
                if ($is_showroom) $showroom_sales += $total; else $web_sales += $total;

                foreach ($order->get_items() as $item) {
                    $pid = $item->get_product_id();
                    $qty = $item->get_quantity();
                    $total_items += $qty;

                    if (!isset($product_sales[$pid])) $product_sales[$pid] = ['name'=>$item->get_name(),'qty'=>0,'total'=>0];
                    $product_sales[$pid]['qty']   += $qty;
                    $product_sales[$pid]['total'] += (float) $item->get_total();

                    $cats = get_the_terms($pid, 'product_cat');
                    if ($cats && !is_wp_error($cats)) {
                        foreach ($cats as $cat) {
                            if (!isset($category_sales[$cat->term_id])) $category_sales[$cat->term_id] = ['name'=>$cat->name,'orders'=>0,'total'=>0];
                            $category_sales[$cat->term_id]['total'] += (float) $item->get_total();
                        }
                    }
                }

                $seen_cats = [];
                foreach ($order->get_items() as $item) {
                    $cats = get_the_terms($item->get_product_id(), 'product_cat');
                    if ($cats && !is_wp_error($cats)) {
                        foreach ($cats as $cat) {
                            if (!in_array($cat->term_id, $seen_cats, true)) {
                                $category_sales[$cat->term_id]['orders'] = ($category_sales[$cat->term_id]['orders'] ?? 0) + 1;
                                $seen_cats[] = $cat->term_id;
                            }
                        }
                    }
                }
            }

            uasort($product_sales, fn($a,$b) => $b['qty'] <=> $a['qty']);
            $top_products = array_slice($product_sales, 0, 10, true);
            uasort($category_sales, fn($a,$b) => $b['total'] <=> $a['total']);
            $avg_ticket = $order_count > 0 ? $total_sales / $order_count : 0;
            $avg_items  = $order_count > 0 ? round($total_items / $order_count, 1) : 0;

            $data = compact('total_sales','order_count','avg_ticket','avg_items','web_sales','showroom_sales','top_products','category_sales');
            set_transient($cache_key, $data, HOUR_IN_SECONDS);
        }

        $data['date_start'] = $date_start;
        $data['date_end']   = $date_end;
        $data['statuses']   = $statuses;

        return $data;
    }

    public function getStockData(): array {
        $repo = new ReportsRepo();
        $threshold = $repo->getThreshold();

        $valid_sorts = ['title', 'sku', 'bodega', 'tienda', 'total'];
        $sort_col    = in_array($_GET['sort'] ?? '', $valid_sorts, true) ? sanitize_key($_GET['sort']) : 'title';
        $sort_dir    = ($_GET['dir'] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';
        $flip_dir    = $sort_dir === 'ASC' ? 'desc' : 'asc';

        $filter = sanitize_key($_GET['stock_filter'] ?? 'all');
        $valid_filters = ['all', 'low_bodega', 'low_tienda', 'zero_bodega', 'zero_tienda'];
        if (!in_array($filter, $valid_filters, true)) $filter = 'all';

        $products = $repo->getStockProducts($filter, $threshold, $sort_col, $sort_dir);
        $totals   = $repo->getStockTotals($threshold);

        $filter_links = [
            'all'          => 'Todos',
            'low_bodega'   => "Bodega < {$threshold}",
            'low_tienda'   => "Showcase < {$threshold}",
            'zero_bodega'  => 'Sin stock bodega',
            'zero_tienda'  => 'Sin stock showcase',
        ];

        $row_style = function(object $row) use ($threshold): string {
            $b = (int) $row->stock_bodega;
            $t = (int) $row->stock_tienda;
            if ($b === 0 && $t === 0) return 'background:#fff5f5;';
            if ($b === 0 || $t === 0) return 'background:#fffbeb;';
            if ($b < $threshold || $t < $threshold) return 'background:#fffff0;';
            return '';
        };

        $sort_link = function(string $col) use ($sort_col, $flip_dir, $sort_dir): string {
            $dir = ($col === $sort_col) ? $flip_dir : 'asc';
            return esc_url(add_query_arg(['page'=>'bsc-reports','tab'=>'stock','sort'=>$col,'dir'=>$dir,'stock_filter'=>$_GET['stock_filter']??'all'], admin_url('admin.php')));
        };
        $sort_arrow = fn(string $col): string => $col === $sort_col ? ($sort_dir==='ASC'?'↑':'↓') : '';

        return compact('products', 'totals', 'threshold', 'filter', 'sort_col', 'sort_dir', 'flip_dir', 'filter_links', 'row_style', 'sort_link', 'sort_arrow');
    }
}
