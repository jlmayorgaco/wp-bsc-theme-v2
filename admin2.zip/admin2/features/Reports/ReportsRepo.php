<?php
namespace BSC\Admin2\Features\Reports;

defined('ABSPATH') || exit;

class ReportsRepo {
    public function getStatuses(): array {
        $all = ['completed', 'processing', 'wc-preparing', 'wc-shipped'];
        if (!isset($_GET['statuses'])) {
            return $all;
        }
        $raw = (array) $_GET['statuses'];
        return array_filter($raw, fn($s) => in_array($s, $all, true));
    }

    public function getOrdersForPeriod(string $date_start, string $date_end, array $statuses): array {
        return wc_get_orders([
            'status'      => $statuses,
            'date_after'  => $date_start . ' 00:00:00',
            'date_before' => $date_end   . ' 23:59:59',
            'limit'       => -1,
        ]);
    }

    public function getStockProducts(string $filter, int $threshold, string $sort_col, string $sort_dir): array {
        global $wpdb;

        $order_map = [
            'title'  => 'p.post_title',
            'sku'    => 'sku_m.meta_value',
            'bodega' => 'CAST(IFNULL(bodega_m.meta_value,0) AS UNSIGNED)',
            'tienda' => 'CAST(IFNULL(tienda_m.meta_value,0) AS UNSIGNED)',
            'total'  => '(CAST(IFNULL(bodega_m.meta_value,0) AS UNSIGNED) + CAST(IFNULL(tienda_m.meta_value,0) AS UNSIGNED))',
        ];
        $order_sql = $order_map[$sort_col] . ' ' . $sort_dir;

        $having = '';
        switch ($filter) {
            case 'low_bodega':  $having = $wpdb->prepare("HAVING stock_bodega < %d", $threshold); break;
            case 'low_tienda':  $having = $wpdb->prepare("HAVING stock_tienda < %d", $threshold); break;
            case 'zero_bodega': $having = "HAVING stock_bodega = 0"; break;
            case 'zero_tienda': $having = "HAVING stock_tienda = 0"; break;
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared — $order_sql and $having are validated
        return $wpdb->get_results(
            "SELECT
                p.ID,
                p.post_title,
                IFNULL(sku_m.meta_value, '')                                              AS sku,
                CAST(IFNULL(bodega_m.meta_value, 0) AS UNSIGNED)                          AS stock_bodega,
                CAST(IFNULL(tienda_m.meta_value, 0) AS UNSIGNED)                          AS stock_tienda,
                CAST(IFNULL(bodega_m.meta_value, 0) AS UNSIGNED)
                + CAST(IFNULL(tienda_m.meta_value, 0) AS UNSIGNED)                        AS stock_total,
                IFNULL(envio_m.meta_value, 'bodega')                                      AS envio_tipo
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} sku_m    ON p.ID = sku_m.post_id    AND sku_m.meta_key    = '_sku'
             LEFT JOIN {$wpdb->postmeta} bodega_m ON p.ID = bodega_m.post_id AND bodega_m.meta_key = '_stock_bodega'
             LEFT JOIN {$wpdb->postmeta} tienda_m ON p.ID = tienda_m.post_id AND tienda_m.meta_key = '_stock_tienda'
             LEFT JOIN {$wpdb->postmeta} envio_m  ON p.ID = envio_m.post_id  AND envio_m.meta_key  = '_envio_tipo'
             WHERE p.post_type = 'product' AND p.post_status = 'publish'
             {$having}
             ORDER BY {$order_sql}, p.post_title ASC"
        );
    }

    public function getStockTotals(int $threshold): ?array {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT
                COUNT(p.ID)                                                                AS total_products,
                SUM(CAST(IFNULL(bodega_m.meta_value,0) AS UNSIGNED))                      AS sum_bodega,
                SUM(CAST(IFNULL(tienda_m.meta_value,0) AS UNSIGNED))                      AS sum_tienda,
                SUM(CASE WHEN CAST(IFNULL(bodega_m.meta_value,0) AS UNSIGNED) < %d THEN 1 ELSE 0 END) AS low_bodega_count,
                SUM(CASE WHEN CAST(IFNULL(bodega_m.meta_value,0) AS UNSIGNED) = 0 THEN 1 ELSE 0 END) AS zero_bodega_count
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} bodega_m ON p.ID = bodega_m.post_id AND bodega_m.meta_key = '_stock_bodega'
             LEFT JOIN {$wpdb->postmeta} tienda_m ON p.ID = tienda_m.post_id AND tienda_m.meta_key = '_stock_tienda'
             WHERE p.post_type = 'product' AND p.post_status = 'publish'",
            $threshold
        ), ARRAY_A );
    }

    public function getThreshold(): int {
        return (int) get_option('bsc_low_stock_threshold', 3);
    }
}
