<?php
namespace BSC\Admin2\Features\ProductEdit;

defined('ABSPATH') || exit;

class ProductEditFeature {

    public function render(): void {
        if ( ! current_user_can('manage_options') && ! current_user_can('edit_products') ) {
            wp_die( esc_html__( 'No tienes permisos.', 'bsc-2-0' ) );
        }

        $product_id = absint( $_GET['id'] ?? 0 );
        if ( ! $product_id || get_post_type($product_id) !== 'product' ) {
            wp_die( esc_html__( 'Producto no encontrado.', 'bsc-2-0' ) );
        }

        $repo = new ProductEditRepo();

        if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset($_POST['bsc_product_edit_nonce']) ) {
            if ( ! wp_verify_nonce( sanitize_text_field(wp_unslash($_POST['bsc_product_edit_nonce'])), 'bsc_product_edit_action' ) ) {
                wp_die( esc_html__( 'Solicitud no válida.', 'bsc-2-0' ) );
            }

            $repo->saveProductData( $product_id, $_POST );

            wp_safe_redirect( admin_url('admin.php?page=bsc-products&saved=1') );
            exit;
        }

        $data = $repo->getProductData( $product_id );
        $data['product_id'] = $product_id;

        $view = new ProductEditView();
        $view->render( $data );
    }
}
