<?php
namespace BSC\Admin2\Features\ProductEdit;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class ProductEditView extends BaseView {

    public function render( array $data = [] ): void {
        $product_id      = $data['product_id'];
        $post            = $data['post'];
        $stock           = $data['stock'];
        $sku             = $data['sku'];
        $gallery         = $data['gallery'];
        $thumbnail_id    = $data['thumbnail_id'];
        $cat_tree_data   = $data['cat_tree_data'];
        $current_cat_ids = $data['current_cat_ids'];
        $all_tags        = $data['all_tags'];
        $cover_fields    = $data['cover_fields'];
        $cover_values    = $data['cover_values'];

        $thumbnail_src = $thumbnail_id ? wp_get_attachment_image_src($thumbnail_id, 'medium')[0] : '';
        wp_enqueue_media();
        ?>
        <div class="wrap bsc-admin-product-edit">
            <h1>Editar Producto <span style="font-weight:400;font-size:0.85em">#<?php echo esc_html($product_id); ?></span></h1>
            <a href="<?php echo esc_url(admin_url('admin.php?page=bsc-products')); ?>" class="page-title-action">← Volver a Productos</a>
            <hr class="wp-header-end">

            <?php if ( isset($_GET['saved']) ): ?>
            <div class="notice notice-success is-dismissible"><p>✓ Producto actualizado correctamente.</p></div>
            <?php endif; ?>

            <form method="post" style="max-width:960px;margin-top:16px">
                <?php wp_nonce_field('bsc_product_edit_action', 'bsc_product_edit_nonce'); ?>

                <div class="bsc-product-edit-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:24px">

                    <!-- LEFT COLUMN -->
                    <div>
                        <!-- A: Básico -->
                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Básico</h2>

                            <label style="display:block;margin-bottom:12px">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Nombre del producto</span>
                                <input type="text" name="post_title" value="<?php echo esc_attr($post->post_title); ?>" class="large-text" required>
                            </label>

                            <label style="display:block;margin-bottom:12px">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Descripción corta</span>
                                <textarea name="post_excerpt" rows="4" class="large-text"><?php echo esc_textarea($post->post_excerpt); ?></textarea>
                            </label>

                            <label style="display:block;margin-bottom:12px">
                                <span style="font-weight:600;display:block;margin-bottom:4px">SKU</span>
                                <input type="text" name="_sku" value="<?php echo esc_attr($sku); ?>" class="regular-text">
                            </label>

                            <label style="display:block">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Estado</span>
                                <select name="post_status">
                                    <option value="publish" <?php selected($post->post_status,'publish'); ?>>Publicado</option>
                                    <option value="draft" <?php selected($post->post_status,'draft'); ?>>Borrador</option>
                                </select>
                            </label>

                            <label style="display:block;margin-top:12px">
                                <input type="checkbox" name="comment_status" value="open" <?php checked($post->comment_status,'open'); ?>>
                                Habilitar reseñas de clientes
                            </label>
                        </div>

                        <!-- C: Tags -->
                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Tags</h2>
                            <label style="display:block">
                                <span style="font-size:12px;color:#666;display:block;margin-bottom:4px">Separados por coma</span>
                                <input type="text" name="product_tag" value="<?php echo esc_attr(implode(', ', is_array($all_tags)?$all_tags:[])); ?>" class="large-text">
                            </label>
                        </div>
                    </div>

                    <!-- RIGHT COLUMN -->
                    <div>
                        <!-- B: Imágenes -->
                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Imagen principal</h2>
                            <div id="bsc-main-image-preview">
                                <?php if ($thumbnail_src): ?>
                                    <img src="<?php echo esc_url($thumbnail_src); ?>" style="max-width:180px;border-radius:6px;margin-bottom:8px;display:block">
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="_thumbnail_id" id="bsc-thumbnail-id" value="<?php echo esc_attr($thumbnail_id ?: ''); ?>">
                            <button type="button" class="button" id="bsc-select-main-image">Seleccionar imagen</button>
                            <?php if ($thumbnail_id): ?>
                                <button type="button" class="button" id="bsc-remove-main-image" style="margin-left:6px">Quitar imagen</button>
                                <input type="hidden" name="_remove_thumbnail" id="bsc-remove-thumbnail-flag" value="">
                            <?php endif; ?>
                        </div>

                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Galería</h2>
                            <div id="bsc-gallery-preview" style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px">
                                <?php foreach ($gallery as $gid):
                                    $gsrc = wp_get_attachment_image_src($gid, [80,80])[0] ?? ''; ?>
                                    <img src="<?php echo esc_url($gsrc); ?>" style="width:72px;height:72px;object-fit:cover;border-radius:4px">
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" name="_product_image_gallery" id="bsc-gallery-ids" value="<?php echo esc_attr(implode(',', $gallery)); ?>">
                            <button type="button" class="button" id="bsc-select-gallery">Editar galería</button>
                        </div>

                        <!-- D: Stock dual -->
                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Stock Dual (BSC)</h2>

                            <label style="display:block;margin-bottom:10px">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Stock Bodega (web)</span>
                                <input type="number" min="0" name="_stock_bodega" value="<?php echo esc_attr($stock['bodega']??0); ?>" style="width:100px">
                            </label>

                            <label style="display:block;margin-bottom:10px">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Stock Tienda (showroom)</span>
                                <input type="number" min="0" name="_stock_tienda" value="<?php echo esc_attr($stock['tienda']??0); ?>" style="width:100px">
                            </label>

                            <label style="display:block">
                                <span style="font-weight:600;display:block;margin-bottom:4px">Tipo de envío</span>
                                <select name="_envio_tipo">
                                    <option value="bodega" <?php selected($stock['envio_tipo']??'bodega','bodega'); ?>>Bodega (web)</option>
                                    <option value="tienda" <?php selected($stock['envio_tipo']??'bodega','tienda'); ?>>Tienda (showroom)</option>
                                    <option value="ambos" <?php selected($stock['envio_tipo']??'bodega','ambos'); ?>>Ambos</option>
                                </select>
                            </label>
                        </div>

                        <!-- E: Covers de Producto -->
                        <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                            <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Covers de Producto</h2>
                            <?php foreach ( $cover_fields as $key => $label ):
                                $att_id  = $cover_values[$key];
                                $img_src = $att_id ? wp_get_attachment_image_url($att_id, 'thumbnail') : '';
                                ?>
                                <div class="bsc-cover-field" style="margin-bottom:16px">
                                    <p style="margin:0 0 4px"><strong><?php echo esc_html($label); ?></strong></p>
                                    <div class="bsc-cover-preview" style="margin-bottom:6px;min-height:40px">
                                        <?php if ($img_src): ?>
                                        <img src="<?php echo esc_url($img_src); ?>"
                                             style="max-width:100%;height:auto;display:block;border-radius:3px">
                                        <?php endif; ?>
                                    </div>
                                    <input type="hidden"
                                           name="<?php echo esc_attr($key); ?>"
                                           id="<?php echo esc_attr($key); ?>"
                                           value="<?php echo esc_attr($att_id ?: ''); ?>">
                                    <button type="button" class="button bsc-cover-select"
                                            data-field="<?php echo esc_attr($key); ?>">
                                        <?php echo $att_id ? 'Cambiar imagen' : 'Seleccionar imagen'; ?>
                                    </button>
                                    <?php if ($att_id): ?>
                                    <button type="button" class="button bsc-cover-remove"
                                            data-field="<?php echo esc_attr($key); ?>"
                                            style="margin-left:4px">Eliminar</button>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- C2: Categorías jerárquicas (BSC-023) – full width -->
                <div class="postbox" style="padding:16px 20px;margin-bottom:16px">
                    <h2 style="margin:0 0 12px;font-size:1rem;border-bottom:1px solid #eee;padding-bottom:8px">Categorías</h2>

                    <!-- Root group tabs -->
                    <div id="bsc-root-tabs" style="display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap"></div>

                    <!-- Branch sections (rendered by JS) -->
                    <div id="bsc-cat-branches"></div>

                    <!-- Hidden product_cat[] inputs populated by JS (only leaf IDs) -->
                    <div id="bsc-cat-hidden-inputs" style="display:none"></div>
                </div>

                <div style="margin-top:8px">
                    <button type="submit" class="button button-primary button-large">Guardar cambios</button>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=bsc-products')); ?>" class="button button-large" style="margin-left:8px">Cancelar</a>
                    <a href="<?php echo esc_url(get_permalink($product_id)); ?>" class="button" target="_blank" style="margin-left:8px">Ver en tienda ↗</a>
                </div>
            </form>
        </div>

        <script>
        (function($){
            // Main image uploader
            var mainFrame;
            $('#bsc-select-main-image').on('click', function(){
                if (mainFrame) { mainFrame.open(); return; }
                mainFrame = wp.media({ title: 'Imagen principal', button: { text: 'Usar imagen' }, multiple: false });
                mainFrame.on('select', function(){
                    var attachment = mainFrame.state().get('selection').first().toJSON();
                    $('#bsc-thumbnail-id').val(attachment.id);
                    $('#bsc-remove-thumbnail-flag').val('');
                    $('#bsc-main-image-preview').html('<img src="'+attachment.url+'" style="max-width:180px;border-radius:6px;margin-bottom:8px;display:block">');
                });
                mainFrame.open();
            });

            $('#bsc-remove-main-image').on('click', function(){
                $('#bsc-thumbnail-id').val('');
                $('#bsc-remove-thumbnail-flag').val('1');
                $('#bsc-main-image-preview').html('');
            });

            // Gallery uploader
            var galleryFrame;
            $('#bsc-select-gallery').on('click', function(){
                if (galleryFrame) { galleryFrame.open(); return; }
                galleryFrame = wp.media({
                    title: 'Galería del producto',
                    button: { text: 'Usar estas imágenes' },
                    multiple: true
                });
                galleryFrame.on('select', function(){
                    var ids = galleryFrame.state().get('selection').map(function(a){ return a.id; });
                    $('#bsc-gallery-ids').val(ids.join(','));
                    var html = galleryFrame.state().get('selection').map(function(a){
                        return '<img src="'+(a.attributes.sizes.thumbnail ? a.attributes.sizes.thumbnail.url : a.attributes.url)+'" style="width:72px;height:72px;object-fit:cover;border-radius:4px">';
                    }).join('');
                    $('#bsc-gallery-preview').html(html);
                });
                galleryFrame.open();
            });

            // Covers uploader
            var coverFrame;
            var currentCoverField;
            $('.bsc-cover-select').on('click', function(e) {
                e.preventDefault();
                currentCoverField = $(this).data('field');
                if (coverFrame) { coverFrame.open(); return; }
                coverFrame = wp.media({ title: 'Seleccionar imagen', button: { text: 'Usar imagen' }, multiple: false });
                coverFrame.on('select', function() {
                    var attachment = coverFrame.state().get('selection').first().toJSON();
                    $('#' + currentCoverField).val(attachment.id);
                    var imgHtml = '<img src="' + attachment.url + '" style="max-width:100%;height:auto;display:block;border-radius:3px">';
                    var $fieldWrap = $('.bsc-cover-select[data-field="'+currentCoverField+'"]').closest('.bsc-cover-field');
                    $fieldWrap.find('.bsc-cover-preview').html(imgHtml);
                    $fieldWrap.find('.bsc-cover-select').text('Cambiar imagen');
                    if ($fieldWrap.find('.bsc-cover-remove').length === 0) {
                        $fieldWrap.append(' <button type="button" class="button bsc-cover-remove" data-field="'+currentCoverField+'" style="margin-left:4px">Eliminar</button>');
                    }
                });
                coverFrame.open();
            });

            $(document).on('click', '.bsc-cover-remove', function(e) {
                e.preventDefault();
                var field = $(this).data('field');
                $('#' + field).val('');
                var $fieldWrap = $(this).closest('.bsc-cover-field');
                $fieldWrap.find('.bsc-cover-preview').empty();
                $fieldWrap.find('.bsc-cover-select').text('Seleccionar imagen');
                $(this).remove();
            });

        })(jQuery);

        // ── BSC-023: Hierarchical Category Selector ──────────────────────
        (function() {
            var catTree     = <?php echo wp_json_encode($cat_tree_data); ?>;
            var currentCats = <?php echo wp_json_encode($current_cat_ids); ?>;
            var ROOT_SLUGS  = ['group-skin-care','group-hair-care','group-make-up'];
            var ROOT_LABELS = {'group-skin-care':'Skin Care','group-hair-care':'Hair Care','group-make-up':'Make Up'};

            // Build flat indexes from tree
            var byId = {}, bySlug = {};
            function indexTree(nodes, parentId) {
                nodes.forEach(function(n) {
                    n.parentId = parentId;
                    byId[n.id]     = n;
                    bySlug[n.slug] = n;
                    if (n.children && n.children.length) indexTree(n.children, n.id);
                });
            }
            indexTree(catTree, 0);

            // Walk ancestors to find which root group a term belongs to
            function getRootSlug(termId) {
                var node = byId[termId];
                while (node && node.parentId !== 0) node = byId[node.parentId];
                return (node && ROOT_SLUGS.indexOf(node.slug) !== -1) ? node.slug : null;
            }

            // Detect initial root from currently assigned cats
            function detectInitialRoot() {
                for (var i = 0; i < currentCats.length; i++) {
                    var r = getRootSlug(currentCats[i]);
                    if (r) return r;
                }
                return ROOT_SLUGS[0];
            }

            var activeRoot = detectInitialRoot();

            function esc(s) {
                return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
            }

            function renderTabs() {
                var html = '';
                ROOT_SLUGS.forEach(function(slug) {
                    html += '<button type="button" class="button' + (slug === activeRoot ? ' button-primary' : '') + '" ' +
                            'data-root="' + esc(slug) + '">' + esc(ROOT_LABELS[slug] || slug) + '</button>';
                });
                document.getElementById('bsc-root-tabs').innerHTML = html;
            }

            function leafHtml(node) {
                var chk = currentCats.indexOf(node.id) !== -1 ? ' checked' : '';
                return '<label style="display:inline-flex;align-items:center;gap:4px;margin:2px 4px;white-space:nowrap;font-size:13px">' +
                       '<input type="checkbox" class="bsc-cat-check" value="' + node.id + '"' + chk + '> ' +
                       esc(node.name) + '</label>';
            }

            function renderBranches() {
                var rootNode   = bySlug[activeRoot];
                var container  = document.getElementById('bsc-cat-branches');

                if (!rootNode || !rootNode.children || !rootNode.children.length) {
                    container.innerHTML = '<p style="color:#888;font-style:italic;font-size:13px">No hay categorías para este grupo.</p>';
                    syncHiddenInputs();
                    return;
                }

                var html = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px">';

                rootNode.children.forEach(function(branch) {
                    html += '<div class="bsc-branch-section" style="border:1px solid #dde0e3;border-radius:4px;padding:10px 12px">';

                    // Header + search
                    html += '<strong style="font-size:0.85rem;display:block;margin-bottom:6px;color:#23282d">' + esc(branch.name) + '</strong>';
                    html += '<input type="text" class="bsc-branch-search" placeholder="Buscar..." ' +
                            'style="width:100%;box-sizing:border-box;padding:3px 6px;border:1px solid #ccd0d4;border-radius:3px;font-size:12px;margin-bottom:8px">';

                    html += '<div class="bsc-branch-items">';

                    if (!branch.children || !branch.children.length) {
                        html += '<em style="color:#aaa;font-size:11px">Sin subcategorías</em>';
                    } else {
                        branch.children.forEach(function(child) {
                            if (child.children && child.children.length) {
                                // Level-3 sub-group: child is a named group, its children are the checkboxes
                                html += '<div class="bsc-subgroup">';
                                html += '<div class="bsc-subgroup-header" style="font-size:11px;font-weight:600;color:#666;margin:6px 0 2px;padding-top:6px;border-top:1px dashed #e0e0e0">' +
                                        esc(child.name) + '</div>';
                                child.children.forEach(function(gc) { html += leafHtml(gc); });
                                html += '</div>';
                            } else {
                                html += leafHtml(child);
                            }
                        });
                    }

                    html += '</div></div>';
                });

                html += '</div>';
                container.innerHTML = html;
                syncHiddenInputs();
            }

            function syncHiddenInputs() {
                var container = document.getElementById('bsc-cat-hidden-inputs');
                container.innerHTML = '';
                document.querySelectorAll('.bsc-cat-check:checked').forEach(function(el) {
                    var inp = document.createElement('input');
                    inp.type  = 'hidden';
                    inp.name  = 'product_cat[]';
                    inp.value = el.value;
                    container.appendChild(inp);
                });
            }

            jQuery(document)
                .on('click', '#bsc-root-tabs .button', function() {
                    activeRoot = this.getAttribute('data-root');
                    renderTabs();
                    renderBranches();
                })
                .on('change', '.bsc-cat-check', syncHiddenInputs)
                .on('input', '.bsc-branch-search', function() {
                    var q       = this.value.toLowerCase().trim();
                    var section = this.closest('.bsc-branch-section');
                    section.querySelectorAll('.bsc-branch-items label').forEach(function(lbl) {
                        lbl.style.display = (!q || lbl.textContent.toLowerCase().indexOf(q) !== -1) ? '' : 'none';
                    });
                    section.querySelectorAll('.bsc-subgroup').forEach(function(sg) {
                        var anyVisible = Array.from(sg.querySelectorAll('label')).some(function(l) {
                            return l.style.display !== 'none';
                        });
                        sg.style.display = (!q || anyVisible) ? '' : 'none';
                    });
                });

            renderTabs();
            renderBranches();
        })();
        </script>
        <?php
    }
}
