<?php
namespace BSC\Admin2\Features\ProductEdit;

defined('ABSPATH') || exit;

class ProductEditRepo {
    public function saveProductData( int $product_id, array $data ): void {
        // Basic fields
        $new_title   = sanitize_text_field( wp_unslash( $data['post_title'] ?? '' ) );
        $new_excerpt = wp_kses_post( wp_unslash( $data['post_excerpt'] ?? '' ) );
        $new_status  = in_array( $data['post_status'] ?? '', ['publish','draft'], true )
            ? sanitize_key( $data['post_status'] )
            : 'draft';

        $comment_status = isset($data['comment_status']) ? 'open' : 'closed';

        wp_update_post([
            'ID'             => $product_id,
            'post_title'     => $new_title,
            'post_excerpt'   => $new_excerpt,
            'post_status'    => $new_status,
            'comment_status' => $comment_status,
        ]);

        // SKU
        $sku = sanitize_text_field( wp_unslash( $data['_sku'] ?? '' ) );
        update_post_meta( $product_id, '_sku', $sku );

        // Main image
        $thumbnail_id = absint( $data['_thumbnail_id'] ?? 0 );
        if ( $thumbnail_id ) {
            set_post_thumbnail( $product_id, $thumbnail_id );
        } elseif ( isset($data['_remove_thumbnail']) && $data['_remove_thumbnail'] ) {
            delete_post_thumbnail( $product_id );
        }

        // Gallery
        $gallery_ids = sanitize_text_field( wp_unslash( $data['_product_image_gallery'] ?? '' ) );
        update_post_meta( $product_id, '_product_image_gallery', $gallery_ids );

        // Categories
        $cat_ids = array_map('absint', (array)($data['product_cat'] ?? []));
        wp_set_object_terms( $product_id, $cat_ids, 'product_cat' );

        // Tags
        $tag_input = sanitize_text_field( wp_unslash( $data['product_tag'] ?? '' ) );
        $tags = array_filter( array_map('trim', explode(',', $tag_input)) );
        wp_set_object_terms( $product_id, $tags, 'product_tag' );

        // Stock dual
        $stock_bodega = max( 0, intval( $data['_stock_bodega'] ?? 0 ) );
        $stock_tienda = max( 0, intval( $data['_stock_tienda'] ?? 0 ) );
        $envio_tipo   = in_array( $data['_envio_tipo'] ?? '', ['bodega','tienda','ambos'], true )
            ? $data['_envio_tipo'] : 'bodega';

        update_post_meta( $product_id, '_stock_bodega', $stock_bodega );
        update_post_meta( $product_id, '_stock_tienda', $stock_tienda );
        update_post_meta( $product_id, '_envio_tipo', $envio_tipo );

        // Covers
        $cover_fields = [
            'bsc_cover_desktop',
            'bsc_cover_mobile',
            '_bsc_extra_image_1',
            '_bsc_extra_image_2',
            '_bsc_extra_image_3',
        ];
        foreach ( $cover_fields as $key ) {
            if (isset($data[$key])) {
                update_post_meta( $product_id, $key, absint($data[$key]) );
            }
        }
    }

    public function getProductData( int $product_id ): array {
        $product = wc_get_product( $product_id );
        $post    = get_post( $product_id );

        $stock      = class_exists('\BSC_Stock') ? \BSC_Stock::get_stock( $product_id ) : ['bodega'=>0, 'tienda'=>0, 'envio_tipo'=>'bodega'];
        $sku        = $product->get_sku();
        $gallery    = $product->get_gallery_image_ids();
        $thumbnail_id = get_post_thumbnail_id( $product_id );

        $all_cats     = get_terms(['taxonomy'=>'product_cat','hide_empty'=>false,'orderby'=>'name']);
        $current_cats = wp_get_object_terms($product_id, 'product_cat', ['fields'=>'ids']);
        $all_tags     = wp_get_object_terms($product_id, 'product_tag', ['fields'=>'names']);

        $build_cat_tree = function(array $terms, int $parent) use (&$build_cat_tree): array {
            $nodes = [];
            foreach ($terms as $t) {
                if ((int) $t->parent === $parent) {
                    $nodes[] = [
                        'id'       => $t->term_id,
                        'name'     => $t->name,
                        'slug'     => $t->slug,
                        'children' => $build_cat_tree($terms, $t->term_id),
                    ];
                }
            }
            return $nodes;
        };
        $cat_tree_data   = $build_cat_tree( is_array($all_cats) ? $all_cats : [], 0 );
        $current_cat_ids = array_values( array_map('intval', is_array($current_cats) ? $current_cats : []) );

        $cover_fields = [
            'bsc_cover_desktop'  => 'Cover Desktop',
            'bsc_cover_mobile'   => 'Cover Mobile',
            '_bsc_extra_image_1' => 'Imagen extra 1',
            '_bsc_extra_image_2' => 'Imagen extra 2',
            '_bsc_extra_image_3' => 'Imagen extra 3',
        ];
        $cover_values = [];
        foreach ( $cover_fields as $key => $label ) {
            $cover_values[$key] = (int) get_post_meta( $product_id, $key, true );
        }

        return [
            'post'            => $post,
            'stock'           => $stock,
            'sku'             => $sku,
            'gallery'         => $gallery,
            'thumbnail_id'    => $thumbnail_id,
            'cat_tree_data'   => $cat_tree_data,
            'current_cat_ids' => $current_cat_ids,
            'all_tags'        => $all_tags,
            'cover_fields'    => $cover_fields,
            'cover_values'    => $cover_values,
        ];
    }
}
