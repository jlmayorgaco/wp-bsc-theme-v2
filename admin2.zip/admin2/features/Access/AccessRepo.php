<?php
namespace BSC\Admin2\Features\Access;

defined('ABSPATH') || exit;

class AccessRepo {
    public const OPTION_NAME = 'bsc_access_control';

    public function getAccessControls(): array {
        $data = get_option(self::OPTION_NAME, []);
        return is_array($data) ? $data : [];
    }

    public function saveAccessControls(array $data): void {
        update_option(self::OPTION_NAME, $data);
    }
}
