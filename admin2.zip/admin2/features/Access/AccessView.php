<?php
namespace BSC\Admin2\Features\Access;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class AccessView extends BaseView {
    public function render(array $data = []): void {
        $config = $data['config'];
        $controls = $data['controls'];
        ?>
        <div class="wrap bsc-admin-access">
            <h1>Control de Acceso BSC</h1>
            <p>Configura a qué pantallas del menú de BSC tienen acceso los distintos roles.</p>
            
            <?php if (isset($_GET['settings-updated'])) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>Permisos actualizados correctamente.</p>
                </div>
            <?php endif; ?>

            <form method="post" action="options.php" class="bsc-access-form">
                <?php
                    settings_fields('bsc_access_control_group');
                ?>
                <table class="wp-list-table widefat fixed striped" style="max-width:800px; margin-top:20px;">
                    <thead>
                        <tr>
                            <th style="width: 200px;">Página / Menú</th>
                            <?php foreach ($config['roles'] as $role_key => $role_label): ?>
                                <th style="text-align:center;"><?php echo esc_html($role_label); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($config['pages'] as $page_slug => $page_label): ?>
                            <tr>
                                <td><strong><?php echo esc_html($page_label); ?></strong></td>
                                <?php foreach ($config['roles'] as $role_key => $role_label): 
                                    $is_mandatory = ($page_slug === 'bsc-orders');
                                    // Use stored settings; fallback to defaults if no option exists.
                                    $has_access = isset($controls[$role_key]) 
                                        ? in_array($page_slug, $controls[$role_key], true) 
                                        : in_array($page_slug, $config['defaults'][$role_key] ?? [], true);
                                    
                                    if ($is_mandatory) {
                                        $has_access = true; // Hardcoded mandatory page
                                    }
                                ?>
                                    <td style="text-align:center;">
                                        <input type="checkbox" 
                                               name="bsc_access_control[<?php echo esc_attr($role_key); ?>][]" 
                                               value="<?php echo esc_attr($page_slug); ?>" 
                                               <?php checked($has_access); ?> 
                                               <?php disabled($is_mandatory); ?> />
                                        
                                        <?php if ($is_mandatory): ?>
                                            <!-- Hidden field to ensure mandatory value is saved since disabled fields are not posted -->
                                            <input type="hidden" 
                                                   name="bsc_access_control[<?php echo esc_attr($role_key); ?>][]" 
                                                   value="<?php echo esc_attr($page_slug); ?>">
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-primary">Guardar Cambios</button>
                </p>
            </form>
        </div>
        
        <style>
            .bsc-access-form {
                background: #fff;
                padding: 20px;
                border: 1px solid #c3c4c7;
                border-radius: 4px;
                margin-top: 20px;
                max-width: 840px;
            }
        </style>
        <?php
    }
}
