<?php
namespace BSC\Admin2\Features\Access;

defined('ABSPATH') || exit;

class AccessFeature {
    private const CONFIG = [
        'roles' => [
            'bsc_employee' => 'BSC Empleado',
            'bsc_operator' => 'BSC Operador',
        ],
        'pages' => [
            'bsc-dashboard'      => 'Dashboard',
            'bsc-orders'         => 'Pedidos',
            'bsc-products'       => 'Productos',
            'bsc-product-edit'   => 'Editar Producto',
            'bsc-reports'        => 'Informes',
            'bsc-showroom'       => 'Venta Presencial',
            'bsc-coupons'        => 'Cupones',
            'bsc-settings'       => 'Configuración',
            'bsc-home-favorites' => 'Home Favorites',
            'bsc-bubble-points'  => 'Bubble Points',
        ],
        'defaults' => [
            'bsc_employee' => ['bsc-dashboard', 'bsc-orders', 'bsc-products', 'bsc-product-edit', 'bsc-showroom', 'bsc-coupons'],
            'bsc_operator' => ['bsc-dashboard', 'bsc-orders', 'bsc-showroom'],
        ],
    ];

    public function init(): void {
        add_action('admin_init', [$this, 'registerSettings']);
    }

    public function registerSettings(): void {
        register_setting(
            'bsc_access_control_group',
            AccessRepo::OPTION_NAME,
            [
                'type' => 'array',
                'sanitize_callback' => [$this, 'sanitizeAccessSettings']
            ]
        );
    }

    public function sanitizeAccessSettings($input) {
        if (!is_array($input)) {
            return [];
        }
        
        $sanitized = [];
        $valid_pages = array_keys(self::CONFIG['pages']);
        $valid_roles = array_keys(self::CONFIG['roles']);

        foreach ($input as $role => $pages) {
            if (in_array($role, $valid_roles, true) && is_array($pages)) {
                $sanitized[$role] = array_filter($pages, function($page) use ($valid_pages) {
                    return in_array($page, $valid_pages, true);
                });
            }
        }
        return $sanitized;
    }

    public function render(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('No tienes permisos.', 'bsc-2-0'));
        }

        $repo = new AccessRepo();
        $controls = $repo->getAccessControls();

        $data = [
            'config'   => self::CONFIG,
            'controls' => $controls,
        ];

        (new AccessView())->render($data);
    }
}
