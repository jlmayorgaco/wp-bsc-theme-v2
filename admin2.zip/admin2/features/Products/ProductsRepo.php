<?php
namespace BSC\Admin2\Features\Products;

defined('ABSPATH') || exit;

class ProductsRepo {
    public function getProducts( array $args = [] ): array {
        $query = new \WP_Query( $args );
        return [
            'posts' => $query->posts,
            'total' => $query->found_posts,
            'pages' => ceil( $query->found_posts / max( 1, $args['posts_per_page'] ?? 20 ) ),
        ];
    }
}
