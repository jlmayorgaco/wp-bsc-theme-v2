<?php
namespace BSC\Admin2\Features\Products;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class ProductsView extends BaseView {

    public function render( array $data = [] ): void {
        $search   = $data['search']   ?? '';
        $status   = $data['status']   ?? '';
        $paged    = $data['paged']    ?? 1;
        $products = $data['products'] ?? [];
        $total    = $data['total']    ?? 0;
        $pages    = $data['pages']    ?? 1;

        ?>
        <div class="wrap bsc-admin-products">
            <h1 class="wp-heading-inline">Productos BSC</h1>
            <hr class="wp-header-end">

            <!-- Filters -->
            <form method="get" style="margin:12px 0;display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">
                <input type="hidden" name="page" value="bsc-products">
                <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Buscar por nombre…" class="regular-text">
                <select name="status">
                    <option value="">Todos</option>
                    <option value="publish" <?php selected($status,'publish'); ?>>Publicados</option>
                    <option value="draft" <?php selected($status,'draft'); ?>>Borradores</option>
                </select>
                <button type="submit" class="button">Filtrar</button>
                <?php if ($search || $status): ?>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=bsc-products')); ?>" class="button">Limpiar</a>
                <?php endif; ?>
            </form>

            <p class="description"><?php echo esc_html($total); ?> productos encontrados.</p>

            <!-- Products table -->
            <table class="wp-list-table widefat fixed striped" style="margin-top:8px">
                <thead>
                    <tr>
                        <th style="width:60px">Imagen</th>
                        <th>Nombre / SKU</th>
                        <th style="width:100px">Precio</th>
                        <th style="width:110px">Stock Bodega</th>
                        <th style="width:110px">Stock Tienda</th>
                        <th style="width:80px">Estado</th>
                        <th style="width:140px">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $products as $post ):
                    $product    = wc_get_product( $post->ID );
                    if ( ! $product ) continue;
                    $sku        = $product->get_sku();
                    $price      = $product->get_regular_price();
                    $sale_price = $product->get_sale_price();
                    $stock      = class_exists('\BSC_Stock') ? \BSC_Stock::get_stock( $post->ID ) : ['bodega'=>0, 'tienda'=>0];
                    $img_id     = $product->get_image_id();
                    $img_src    = $img_id
                        ? wp_get_attachment_image_src( $img_id, [ 60, 60 ] )[0] ?? ''
                        : wc_placeholder_img_src();
                    $edit_url   = admin_url( 'admin.php?page=bsc-product-edit&id=' . $post->ID );
                    $view_url   = get_permalink( $post->ID );
                    $low_threshold = (int) get_option('bsc_low_stock_threshold', 3);
                ?>
                <tr>
                    <td>
                        <img src="<?php echo esc_url($img_src); ?>" alt="" loading="lazy" style="width:56px;height:56px;object-fit:cover;border-radius:6px;">
                    </td>
                    <td>
                        <strong><a href="<?php echo esc_url($edit_url); ?>"><?php echo esc_html($post->post_title); ?></a></strong>
                        <?php if ($sku): ?><br><code style="font-size:11px;color:#888"><?php echo esc_html($sku); ?></code><?php endif; ?>
                    </td>
                    <td>
                        <?php if ($sale_price): ?>
                            <del style="color:#aaa;font-size:11px"><?php echo wc_price($price); ?></del><br>
                            <strong><?php echo wp_kses_post(wc_price($sale_price)); ?></strong>
                        <?php else: ?>
                            <?php echo wp_kses_post(wc_price($price)); ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <input type="number" min="0"
                            class="bsc-stock-input"
                            data-product-id="<?php echo esc_attr($post->ID); ?>"
                            data-type="bodega"
                            data-original="<?php echo esc_attr($stock['bodega']); ?>"
                            value="<?php echo esc_attr($stock['bodega']); ?>"
                            style="width:60px;text-align:center<?php echo ($stock['bodega'] < $low_threshold ? ';border-color:#e53e3e;background:#fff5f5' : ''); ?>">
                    </td>
                    <td>
                        <input type="number" min="0"
                            class="bsc-stock-input"
                            data-product-id="<?php echo esc_attr($post->ID); ?>"
                            data-type="tienda"
                            data-original="<?php echo esc_attr($stock['tienda']); ?>"
                            value="<?php echo esc_attr($stock['tienda']); ?>"
                            style="width:60px;text-align:center">
                    </td>
                    <td>
                        <?php if ($post->post_status === 'publish'): ?>
                            <span style="color:#276749;font-weight:600">✓ Publicado</span>
                        <?php else: ?>
                            <span style="color:#888">Borrador</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo esc_url($edit_url); ?>" class="button button-small">Editar</a>
                        <a href="<?php echo esc_url($view_url); ?>" class="button button-small" target="_blank" title="Ver en tienda">↗</a>
                        <button class="button button-small bsc-stock-history-btn"
                            data-product-id="<?php echo esc_attr($post->ID); ?>"
                            data-product-name="<?php echo esc_attr($post->post_title); ?>"
                            title="Historial de stock">🕐</button>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if ( empty($products) ): ?>
                <tr><td colspan="7" style="text-align:center;padding:20px;color:#888">No hay productos.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <?php if ($pages > 1): ?>
            <div style="margin:16px 0;display:flex;gap:8px;align-items:center">
                <?php if ($paged > 1): ?>
                    <a href="<?php echo esc_url(add_query_arg(['paged' => $paged-1])); ?>" class="button">← Anterior</a>
                <?php endif; ?>
                <span style="color:#666">Página <?php echo esc_html($paged); ?> de <?php echo esc_html($pages); ?></span>
                <?php if ($paged < $pages): ?>
                    <a href="<?php echo esc_url(add_query_arg(['paged' => $paged+1])); ?>" class="button">Siguiente →</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- BSC-066: Stock history modal -->
        <div id="bsc-stock-modal" style="display:none;position:fixed;inset:0;z-index:100000">
            <div id="bsc-stock-modal-overlay" style="position:absolute;inset:0;background:rgba(0,0,0,0.5)"></div>
            <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:#fff;border-radius:10px;padding:24px;max-width:800px;width:90%;max-height:80vh;overflow-y:auto;box-shadow:0 10px 40px rgba(0,0,0,0.2)">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
                    <h2 id="bsc-stock-modal-title" style="margin:0;font-size:1.1rem">Historial de stock</h2>
                    <button id="bsc-stock-modal-close" class="button" style="font-size:1.2rem;line-height:1">×</button>
                </div>
                <div id="bsc-stock-modal-body"></div>
            </div>
        </div>

        <?php wp_nonce_field('bsc_products_nonce', 'bsc_products_nonce_field'); ?>
        <?php
    }
}
