<?php
namespace BSC\Admin2\Features\Products;

defined('ABSPATH') || exit;

class ProductsFeature {

    public function render(): void {
        if ( ! current_user_can('manage_options') && ! current_user_can('edit_products') ) {
            wp_die( esc_html__( 'No tienes permisos para ver esta página.', 'bsc-2-0' ) );
        }

        $search     = sanitize_text_field( $_GET['s'] ?? '' );
        $status     = in_array( $_GET['status'] ?? '', [ 'publish', 'draft' ], true ) ? $_GET['status'] : '';
        $paged      = max( 1, intval( $_GET['paged'] ?? 1 ) );
        $per_page   = 20;

        $args = [
            'post_type'              => 'product',
            'post_status'            => $status ?: [ 'publish', 'draft' ],
            'posts_per_page'         => $per_page,
            'paged'                  => $paged,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false,
        ];
        if ( $search ) {
            $args['s'] = $search;
        }

        $repo = new ProductsRepo();
        $data = $repo->getProducts( $args );

        $view = new ProductsView();
        $view->render([
            'search'   => $search,
            'status'   => $status,
            'paged'    => $paged,
            'products' => $data['posts'],
            'total'    => $data['total'],
            'pages'    => $data['pages'],
        ]);
    }

    public function ajaxUpdateProductStock(): void {
        check_ajax_referer('bsc_products_nonce', 'nonce');
        if ( ! current_user_can('manage_options') && ! current_user_can('edit_products') ) {
            wp_send_json_error([ 'message' => 'Sin permisos' ], 403);
        }

        $product_id = absint( $_POST['product_id'] ?? 0 );
        $type       = in_array( $_POST['type'] ?? '', [ 'bodega', 'tienda' ], true ) ? $_POST['type'] : 'bodega';
        $value      = max( 0, intval( $_POST['value'] ?? 0 ) );

        if ( ! $product_id || get_post_type($product_id) !== 'product' ) {
            wp_send_json_error([ 'message' => 'Producto inválido' ], 400);
        }

        $service = new ProductsService();
        $service->updateProductStockInline( $product_id, $type, $value );

        wp_send_json_success([ 'new_value' => $value ]);
    }

    public function ajaxAdjustStock(): void {
        check_ajax_referer('bsc_products_nonce', 'nonce');
        if ( ! current_user_can('manage_options') && ! current_user_can('edit_products') ) {
            wp_send_json_error([ 'message' => 'Sin permisos' ], 403);
        }

        $product_id = absint( $_POST['product_id'] ?? 0 );
        $type       = in_array( $_POST['type'] ?? '', [ 'bodega', 'tienda' ], true ) ? $_POST['type'] : 'bodega';
        $delta      = intval( $_POST['delta'] ?? 0 );
        $reason     = sanitize_text_field( $_POST['reason'] ?? '' );

        if ( ! $product_id || get_post_type($product_id) !== 'product' ) {
            wp_send_json_error([ 'message' => 'Producto inválido' ], 400);
        }

        $service = new ProductsService();
        $new_stock = $service->adjustStock( $product_id, $type, $delta, $reason );

        wp_send_json_success([ 'new_stock' => $new_stock ]);
    }

    public function ajaxGetStockLog(): void {
        check_ajax_referer('bsc_products_nonce', 'nonce');
        if ( ! current_user_can('manage_options') && ! current_user_can('edit_products') ) {
            wp_send_json_error([ 'message' => 'Sin permisos' ], 403);
        }

        $product_id = absint( $_GET['product_id'] ?? 0 );
        if ( ! $product_id ) {
            wp_send_json_error([ 'message' => 'Producto inválido' ], 400);
        }

        $service = new ProductsService();
        $enriched = $service->getStockLog( $product_id );

        wp_send_json_success([ 'log' => $enriched ]);
    }

    public static function enqueueInlineJs( string $hook ): void {
        if ( strpos($hook, 'bsc-products') === false ) return;
        $nonce = wp_create_nonce('bsc_products_nonce');
        $js = self::getInlineJs( $nonce );
        wp_add_inline_script('jquery', $js);
    }

    private static function getInlineJs( string $nonce ): string {
        return <<<JS
(function($){
  var bscNonce = '{$nonce}';

  // Inline stock edit: on blur, save the new value
  $(document).on('change blur', '.bsc-stock-input', function(){
    var \$input = $(this);
    var productId = \$input.data('product-id');
    var type      = \$input.data('type');
    var value     = parseInt(\$input.val(), 10);
    if (isNaN(value) || value < 0) { \$input.val(\$input.data('original')); return; }

    \$input.prop('disabled', true);
    $.post(ajaxurl, {
      action: 'bsc_update_product_stock',
      nonce: bscNonce,
      product_id: productId,
      type: type,
      value: value
    }).done(function(res){
      if (res.success) {
        \$input.data('original', res.data.new_value);
        \$input.css('background','#e6ffed');
        setTimeout(function(){ \$input.css('background',''); }, 1200);
      } else {
        \$input.val(\$input.data('original'));
      }
    }).always(function(){ \$input.prop('disabled', false); });
  });

  // Stock history modal
  $(document).on('click', '.bsc-stock-history-btn', function(){
    var productId = $(this).data('product-id');
    var productName = $(this).data('product-name');
    $('#bsc-stock-modal-title').text('Historial: ' + productName);
    $('#bsc-stock-modal-body').html('<p>Cargando…</p>');
    $('#bsc-stock-modal').show();

    $.get(ajaxurl, {
      action: 'bsc_get_stock_log',
      nonce: bscNonce,
      product_id: productId
    }).done(function(res){
      if (!res.success || !res.data.log.length) {
        $('#bsc-stock-modal-body').html('<p>Sin movimientos registrados.</p>');
        return;
      }
      var rows = res.data.log.map(function(e){
        var delta = e.delta > 0 ? '+'+e.delta : e.delta;
        var color = e.delta > 0 ? '#276749' : '#c53030';
        return '<tr><td>'+e.date+'</td><td>'+e.type+'</td>'
          +'<td style="color:'+color+';font-weight:700">'+delta+'</td>'
          +'<td>'+e.before+' → '+e.after+'</td>'
          +'<td>'+e.username+'</td><td>'+e.reason+'</td></tr>';
      }).join('');
      $('#bsc-stock-modal-body').html(
        '<table class="wp-list-table widefat"><thead><tr>'
        +'<th>Fecha</th><th>Tipo</th><th>Δ</th><th>Antes→Después</th><th>Usuario</th><th>Razón</th>'
        +'</tr></thead><tbody>'+rows+'</tbody></table>'
      );
    });
  });

  // Close modal
  $(document).on('click', '#bsc-stock-modal-close, #bsc-stock-modal-overlay', function(){
    $('#bsc-stock-modal').hide();
  });
})(jQuery);
JS;
    }
}
