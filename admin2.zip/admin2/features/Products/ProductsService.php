<?php
namespace BSC\Admin2\Features\Products;

defined('ABSPATH') || exit;

class ProductsService {

    public function updateProductStockInline( int $product_id, string $type, int $value ): void {
        $meta_key = ( $type === 'tienda' ) ? '_stock_tienda' : '_stock_bodega';
        $old      = (int) get_post_meta( $product_id, $meta_key, true );

        update_post_meta( $product_id, $meta_key, $value );

        if ( class_exists('\BSC_Stock') && $old !== $value ) {
            \BSC_Stock::adjust( $product_id, $type, $value - $old, 'Edición inline BSC Products' );
            update_post_meta( $product_id, $meta_key, $value );
        }
    }

    public function adjustStock( int $product_id, string $type, int $delta, string $reason ): int {
        return class_exists('\BSC_Stock')
            ? \BSC_Stock::adjust( $product_id, $type, $delta, $reason )
            : 0;
    }

    public function getStockLog( int $product_id ): array {
        if ( ! class_exists('\BSC_Stock') ) return [];

        $log = \BSC_Stock::get_log( $product_id );

        return array_map( function( $entry ) {
            $entry['username'] = $entry['user_id']
                ? get_userdata( $entry['user_id'] )->display_name ?? '—'
                : '—';
            return $entry;
        }, $log );
    }
}
