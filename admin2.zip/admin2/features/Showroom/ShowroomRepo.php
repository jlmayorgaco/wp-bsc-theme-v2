<?php
namespace BSC\Admin2\Features\Showroom;

defined('ABSPATH') || exit;

class ShowroomRepo {

    public function getRecentOrders( int $limit = 10 ): array {
        return wc_get_orders([
            'meta_key'   => '_bsc_is_showroom_sale',
            'meta_value' => '1',
            'limit'      => $limit,
            'orderby'    => 'date',
            'order'      => 'DESC',
        ]);
    }
}
