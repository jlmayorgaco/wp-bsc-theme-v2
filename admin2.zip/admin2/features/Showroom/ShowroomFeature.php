<?php
namespace BSC\Admin2\Features\Showroom;

defined('ABSPATH') || exit;

class ShowroomFeature {

    public function render(): void {
        if (!current_user_can('manage_options') && !current_user_can('edit_orders')) {
            wp_die(esc_html__('No tienes permisos.', 'bsc-2-0'));
        }

        $repo = new ShowroomRepo();
        $recent_orders = $repo->getRecentOrders();

        $view = new ShowroomView();
        $view->render([
            'recent_orders' => $recent_orders,
        ]);
    }

    public function ajaxSearch(): void {
        check_ajax_referer('bsc_admin_orders', 'nonce');
        if (!current_user_can('manage_options') && !current_user_can('edit_orders')) wp_send_json_error();

        $q = sanitize_text_field($_POST['q'] ?? '');
        if (strlen($q) < 2) wp_send_json_success([]);

        $service = new ShowroomService();
        $results = $service->searchProducts($q);

        wp_send_json_success($results);
    }

    public function ajaxRegisterSale(): void {
        check_ajax_referer('bsc_admin_orders', 'nonce');
        if (!current_user_can('manage_options') && !current_user_can('edit_orders')) {
            wp_send_json_error(['message' => 'Sin permisos']);
        }

        $items_raw      = sanitize_text_field($_POST['items'] ?? '[]');
        $items          = json_decode(stripslashes($items_raw), true);
        $payment        = sanitize_text_field($_POST['payment_method'] ?? 'efectivo');
        $customer_name  = sanitize_text_field($_POST['customer_name'] ?? '');
        $customer_phone = sanitize_text_field($_POST['customer_phone'] ?? '');
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');

        if (!is_array($items)) {
            $items = [];
        }

        $service = new ShowroomService();
        $result = $service->registerSale($items, $payment, $customer_name, $customer_phone, $customer_email);

        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(['message' => $result['message']]);
        }
    }
}
