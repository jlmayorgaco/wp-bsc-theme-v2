<?php
namespace BSC\Admin2\Features\Showroom;

defined('ABSPATH') || exit;

class ShowroomService {

    public function searchProducts( string $query, int $limit = 12 ): array {
        $products = wc_get_products([
            's'       => $query,
            'limit'   => $limit,
            'status'  => 'publish',
            'return'  => 'objects',
        ]);

        $results = [];
        foreach ($products as $product) {
            $results[] = [
                'id'           => $product->get_id(),
                'name'         => $product->get_name(),
                'sku'          => $product->get_sku(),
                'price'        => (float) $product->get_price(),
                'stock_tienda' => (int) get_post_meta($product->get_id(), '_stock_tienda', true),
            ];
        }

        return $results;
    }

    public function registerSale( array $items, string $payment, string $customer_name, string $customer_phone, string $customer_email ): array {
        if (empty($items)) {
            return ['success' => false, 'message' => 'Sin productos'];
        }

        $order = wc_create_order(['customer_id' => 0]);

        foreach ($items as $item) {
            $product_id = absint($item['id'] ?? 0);
            $qty        = max(1, absint($item['qty'] ?? 1));
            $product    = wc_get_product($product_id);
            if (!$product) continue;
            $order->add_product($product, $qty);
        }

        if ($customer_name) {
            $parts = explode(' ', $customer_name, 2);
            $order->set_billing_first_name($parts[0]);
            $order->set_billing_last_name($parts[1] ?? '');
        }
        if ($customer_phone) $order->set_billing_phone($customer_phone);
        if ($customer_email) $order->set_billing_email($customer_email);

        $order->set_payment_method($payment);
        $order->set_payment_method_title(ucfirst($payment));

        $order->calculate_totals();
        $order->update_status('completed', 'Venta presencial registrada desde BSC Admin.');
        $order->save();

        $order_id = $order->get_id();

        update_post_meta($order_id, '_bsc_is_showroom_sale', '1');

        if (class_exists('\BSC_Stock')) {
            \BSC_Stock::deduct_tienda($order_id);
        }

        return [
            'success'  => true,
            'order_id' => $order_id,
            'edit_url' => $order->get_edit_order_url(),
            'message'  => 'Venta registrada correctamente',
        ];
    }
}
