<?php
namespace BSC\Admin2\Features\Coupons;

use WC_Coupon;

defined('ABSPATH') || exit;

class CouponsService {
    public function createCoupon(array $data): bool {
        $code = sanitize_text_field(strtolower(wp_unslash($data['coupon_code'] ?? '')));
        if (!$code) {
            return false;
        }

        $discount_type = sanitize_text_field($data['discount_type'] ?? 'percent');
        $amount        = (float) ($data['coupon_amount'] ?? 0);
        $expiry        = sanitize_text_field($data['expiry_date'] ?? '');
        $description   = sanitize_textarea_field($data['coupon_description'] ?? '');
        $usage_limit   = absint($data['usage_limit'] ?? 0);
        $min_amount    = (float) ($data['minimum_amount'] ?? 0);

        $coupon = new WC_Coupon();
        $coupon->set_code($code);
        $coupon->set_discount_type(in_array($discount_type, ['percent', 'fixed_cart', 'fixed_product'], true) ? $discount_type : 'percent');
        $coupon->set_amount($amount);
        $coupon->set_description($description);
        if ($expiry) {
            $coupon->set_date_expires(strtotime($expiry));
        }
        if ($usage_limit) {
            $coupon->set_usage_limit($usage_limit);
        }
        if ($min_amount) {
            $coupon->set_minimum_amount($min_amount);
        }
        $coupon->save();

        return true;
    }

    public function deleteCoupon(int $coupon_id): void {
        wp_delete_post($coupon_id, true);
    }
}
