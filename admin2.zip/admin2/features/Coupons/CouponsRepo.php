<?php
namespace BSC\Admin2\Features\Coupons;

use WP_Query;

defined('ABSPATH') || exit;

class CouponsRepo {
    public function getCoupons(int $limit = 50): WP_Query {
        $args = [
            'post_type'      => 'shop_coupon',
            'posts_per_page' => $limit,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];
        return new WP_Query($args);
    }
}
