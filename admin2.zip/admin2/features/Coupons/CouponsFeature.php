<?php
namespace BSC\Admin2\Features\Coupons;

defined('ABSPATH') || exit;

class CouponsFeature {
    public function handleActions(): void {
        if (!isset($_GET['page']) || $_GET['page'] !== 'bsc-coupons') {
            return;
        }
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) {
            return;
        }

        $service = new CouponsService();

        // Create coupon
        if (isset($_POST['bsc_create_coupon_nonce'])) {
            if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['bsc_create_coupon_nonce'])), 'bsc_create_coupon')) {
                wp_die(esc_html__('Nonce inválido.', 'bsc-2-0'));
            }

            if ($service->createCoupon($_POST)) {
                wp_safe_redirect(add_query_arg(['page' => 'bsc-coupons', 'bsc_notice' => 'created'], admin_url('admin.php')));
                exit;
            }
        }

        // Delete coupon
        if (isset($_GET['bsc_delete_coupon'], $_GET['bsc_delete_nonce'])) {
            $coupon_id = absint($_GET['bsc_delete_coupon']);
            if (wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['bsc_delete_nonce'])), 'bsc_delete_coupon_' . $coupon_id)) {
                $service->deleteCoupon($coupon_id);
            }
            wp_safe_redirect(add_query_arg(['page' => 'bsc-coupons', 'bsc_notice' => 'deleted'], admin_url('admin.php')));
            exit;
        }
    }

    public function render(): void {
        if (!current_user_can('manage_options') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'bsc-2-0'));
        }

        $repo = new CouponsRepo();
        $coupons_query = $repo->getCoupons();

        $data = [
            'coupons_query' => $coupons_query,
            'notice' => $_GET['bsc_notice'] ?? null,
        ];

        (new CouponsView())->render($data);
    }
}
