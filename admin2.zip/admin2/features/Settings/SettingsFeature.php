<?php
namespace BSC\Admin2\Features\Settings;

defined('ABSPATH') || exit;

class SettingsFeature {
    public function render(): void {
        $this->handleSave();
        $view = new SettingsView();
        $view->render();
    }

    private function handleSave(): void {
        if ( 'POST' === $_SERVER['REQUEST_METHOD'] && isset($_POST['bsc_settings_nonce']) ) {
            if ( ! wp_verify_nonce( sanitize_text_field(wp_unslash($_POST['bsc_settings_nonce'])), 'bsc_settings_action' ) ) {
                wp_die( esc_html__( 'Solicitud no válida.', 'bsc-2-0' ) );
            }

            update_option('bsc_whatsapp_number',          preg_replace('/[^0-9]/', '', $_POST['bsc_whatsapp_number'] ?? '573156922859'));
            update_option('bsc_contact_email',             sanitize_email($_POST['bsc_contact_email'] ?? ''));
            update_option('bsc_free_shipping_threshold',   max(0, intval($_POST['bsc_free_shipping_threshold'] ?? 300000)));
            update_option('bsc_bogota_shipping_label',     sanitize_text_field($_POST['bsc_bogota_shipping_label'] ?? 'Bogotá'));
            update_option('bsc_default_max_products_slider', max(1, intval($_POST['bsc_default_max_products_slider'] ?? 5)));
            update_option('bsc_email_from_name',           sanitize_text_field($_POST['bsc_email_from_name'] ?? 'Bubble Skin Care'));
            update_option('bsc_email_from_address',        sanitize_email($_POST['bsc_email_from_address'] ?? ''));
            update_option('bsc_low_stock_threshold',       max(0, intval($_POST['bsc_low_stock_threshold'] ?? 3)));

            echo '<div class="notice notice-success is-dismissible"><p>✓ Configuración guardada.</p></div>';
        }
    }
}
