<?php
namespace BSC\Admin2\Features\Settings;

use BSC\Admin2\Core\BaseView;

defined('ABSPATH') || exit;

class SettingsView extends BaseView {
    public function render(array $data = []): void {
        if ( ! current_user_can('manage_options') ) {
            wp_die( esc_html__( 'No tienes permisos para ver esta página.', 'bsc-2-0' ) );
        }
        ?>
        <div class="wrap">
            <h1>Configuración BSC</h1>
            <form method="post">
                <?php wp_nonce_field('bsc_settings_action', 'bsc_settings_nonce'); ?>
                <table class="form-table">
                    <tr><th colspan="2"><h2 style="margin:0">General</h2></th></tr>
                    <tr>
                        <th><label for="bsc_whatsapp_number">Número de WhatsApp</label></th>
                        <td>
                            <input type="text" id="bsc_whatsapp_number" name="bsc_whatsapp_number"
                                value="<?php echo esc_attr(get_option('bsc_whatsapp_number','573156922859')); ?>"
                                class="regular-text" placeholder="573156922859">
                            <p class="description">Solo números, con código de país. Ej: 573156922859</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bsc_contact_email">Email de contacto</label></th>
                        <td>
                            <input type="email" id="bsc_contact_email" name="bsc_contact_email"
                                value="<?php echo esc_attr(get_option('bsc_contact_email', defined('BSC_CONTACT_EMAIL') ? BSC_CONTACT_EMAIL : '')); ?>"
                                class="regular-text">
                        </td>
                    </tr>

                    <tr><th colspan="2"><h2 style="margin:16px 0 0">Tienda</h2></th></tr>
                    <tr>
                        <th><label for="bsc_free_shipping_threshold">Umbral de envío gratis (COP)</label></th>
                        <td>
                            <input type="number" id="bsc_free_shipping_threshold" name="bsc_free_shipping_threshold"
                                value="<?php echo esc_attr(get_option('bsc_free_shipping_threshold',300000)); ?>"
                                class="regular-text" min="0" step="1000">
                            <p class="description">Se oculta el envío gratis si el subtotal (después de descuento) es menor a este valor.</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bsc_bogota_shipping_label">Label tarifa Bogotá</label></th>
                        <td>
                            <input type="text" id="bsc_bogota_shipping_label" name="bsc_bogota_shipping_label"
                                value="<?php echo esc_attr(get_option('bsc_bogota_shipping_label','Bogotá')); ?>"
                                class="regular-text">
                            <p class="description">Texto que identifica la tarifa de Bogotá en WooCommerce Envíos (debe coincidir con el label de la zona).</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bsc_default_max_products_slider">Productos por slider</label></th>
                        <td>
                            <input type="number" id="bsc_default_max_products_slider" name="bsc_default_max_products_slider"
                                value="<?php echo esc_attr(get_option('bsc_default_max_products_slider',5)); ?>"
                                class="small-text" min="1" max="20">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bsc_low_stock_threshold">Umbral de stock bajo</label></th>
                        <td>
                            <input type="number" id="bsc_low_stock_threshold" name="bsc_low_stock_threshold"
                                value="<?php echo esc_attr(get_option('bsc_low_stock_threshold',3)); ?>"
                                class="small-text" min="0">
                            <p class="description">Productos con stock bodega menor a este valor aparecen como alerta en el Dashboard.</p>
                        </td>
                    </tr>

                    <tr><th colspan="2"><h2 style="margin:16px 0 0">Emails BSC</h2></th></tr>
                    <tr>
                        <th><label for="bsc_email_from_name">Nombre del remitente</label></th>
                        <td>
                            <input type="text" id="bsc_email_from_name" name="bsc_email_from_name"
                                value="<?php echo esc_attr(get_option('bsc_email_from_name','Bubble Skin Care')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="bsc_email_from_address">Email del remitente</label></th>
                        <td>
                            <input type="email" id="bsc_email_from_address" name="bsc_email_from_address"
                                value="<?php echo esc_attr(get_option('bsc_email_from_address','')); ?>"
                                class="regular-text">
                        </td>
                    </tr>
                </table>

                <?php submit_button('Guardar configuración'); ?>
            </form>
        </div>
        <?php
    }
}
