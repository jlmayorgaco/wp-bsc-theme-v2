<?php

// Las rutas bajan desde admin2/ hacia el módulo específico
require_once __DIR__ . '/modules/showroom/BSC_Admin_Showroom_View.php';
require_once __DIR__ . '/modules/showroom/BSC_Admin_Showroom_Product_Search.php';
require_once __DIR__ . '/modules/showroom/BSC_Admin_Showroom_Sale_Service.php';
require_once __DIR__ . '/modules/showroom/BSC_Admin_Showroom.php';

$showroomView = new BSC_Admin_Showroom_View();
$showroomSearch = new BSC_Admin_Showroom_Product_Search();
$showroomSaleService = new BSC_Admin_Showroom_Sale_Service();

$showroomPage = new BSC_Admin_Showroom(
    $showroomView,
    $showroomSearch,
    $showroomSaleService
);
$showroomPage->register();





$dashboardPage = new BSC_Admin_Dashboard();
$settingsPage  = new BSC_Admin_Settings();

$menu = new BSC_Admin_Menu([
    'dashboard'      => [$dashboardPage, 'render'],
    'showroom'       => 'bsc_render_showroom_page',

    'orders'         => 'bsc_render_orders_page',
    'coupons'        => 'bsc_render_coupons_page',
    'products'       => 'bsc_render_products_page',
    'reports'        => 'bsc_render_reports_page',

    'home_favorites' => 'bsc_home_favorites_settings_page',
    'bubble_points'  => 'bsc_bp_render_admin_screen',
    
    'access'         => 'bsc_render_access_page',
    'settings'       => [$settingsPage, 'render']
]);

$menuVisibility = new BSC_Admin_Menu_Visibility();

$menu->register();
$menuVisibility->register();
?>