<?php
namespace BSC\Admin2;

defined('ABSPATH') || exit;

class Boot {
    public static function init(): void {
        self::registerAutoloader();
    }

    private static function registerAutoloader(): void {
        spl_autoload_register(function ($class) {
            $prefix = 'BSC\\Admin2\\';
            $base_dir = __DIR__ . '/';

            $len = strlen($prefix);
            if (strncmp($prefix, $class, $len) !== 0) {
                return;
            }

            $relative_class = substr($class, $len);
            $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

            if (file_exists($file)) {
                require $file;
            }
        });
    }
}

// Initialize boot wrapper
Boot::init();
